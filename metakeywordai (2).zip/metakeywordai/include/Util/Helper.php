<?php
namespace MetaKeywordAI\Util;

// Any helper functions or utility classes can be defined here
