<style>
    /* CSS style to position radio buttons in front of input boxes and text areas */
    .meta-title input[type="radio"],
    .meta-description input[type="radio"] {
        display: inline-block;
        vertical-align: middle;
        margin-right: 5px;
        /* Adjust the margin as needed */
    }

    .meta-description textarea {
        display: inline-block;
        vertical-align: middle;
        width: calc(100% - 30px);
        /* Adjust the width as needed */
    }
</style>
<?php

function get_post_description($post_id)
{
    $post = get_post($post_id);
    if ($post) {
        // Get the post content and strip HTML tags
        $description = wp_strip_all_tags($post->post_content);
        return $description;
    }
    return false;
}


?>
<!-- cg-page-list-wrapper -->
<div class="cg-page-list-wrapper">
    <!-- Heading for the page and post list -->
    <h2>Page & Post List</h2>

    <!-- Navigation tabs for switching between pages, posts, and products -->
    <ul class="nav nav-tabs" id="myTabs" role="tablist">
        <!-- Tab for displaying pages -->
        <li class="nav-item">
            <a class="nav-link active" id="pages-tab" data-toggle="tab" href="#pages" role="tab" aria-controls="pages" aria-selected="true">Pages</a>
        </li>
        <!-- Tab for displaying posts -->
        <li class="nav-item">
            <a class="nav-link" id="posts-tab" data-toggle="tab" href="#posts" role="tab" aria-controls="posts" aria-selected="false">Posts</a>
        </li>
        <!-- Tab for displaying Products -->
        <li class="nav-item">
            <a class="nav-link" id="products-tab" data-toggle="tab" href="#products" role="tab" aria-controls="products" aria-selected="false">Products</a>
        </li>
    </ul>

    <!-- Tab content container -->
    <div class="tab-content" id="myTabsContent">
        <!-- Tab content for pages -->
        <div class="tab-pane fade show active" id="pages" role="tabpanel" aria-labelledby="pages-tab">
            <!-- Heading for page titles and actions -->
            <div class="row">
                <!-- Column for page titles -->
                <div class="col-md-2">
                    <h6>Page Title</h6>
                </div>

                <div class="col-md-2">
                    <h6>URL</h6>
                </div>

                <div class="col-md-2">
                    <h6>Meta Title</h6>
                </div>


                <div class="col-md-2">
                    <h6>Meta Description</h6>
                </div>

                <div class="col-md-2">
                    <h6>Alt Tags</h6>
                </div>
                <!-- Column for actions related to pages -->
                <div class="col-md-2">
                    <h6>Action</h6>
                </div>
            </div>
            <!-- Unordered list for displaying page titles -->
            <ul>
                <?php foreach ($pages as $page) :

                    $post_description = get_post_description($page->ID);
                ?>
                    <li class="row" id="rowid_<?php echo $page->ID; ?>">
                        <!-- Column for page title -->
						<?php $meta= get_post_meta($page->ID); 
						print_r($meta); ?>
                        <div class="col-md-2">
                            <p><?php echo $page->post_title; ?></p>
                            <input type="hidden" id="psdes_<?php echo $page->ID; ?>" name="post_description" value="<?php echo esc_attr($post_description); ?>">
                        </div>
                        <div class="col-md-2">
                            <p><?php echo $page->post_title; ?></p>
                        </div>
                        <div class="col-md-2">
                            <div class="meta-title">
                                <!-- <input type="radio" name="meta_t_radio_<?php echo $page->ID; ?>" value="1"> -->
                                <input type="text" name="meta_title_1_<?php echo $page->ID; ?>" value="<?php echo get_post_meta($page->ID, '_aioseo_title', true); ?>"><br>
                                <input type="checkbox" name="meta_t_radio_<?php echo $page->ID; ?>" value="2">
                                <input type="text" name="meta_title_2_<?php echo $page->ID; ?>" placeholder="Meta Title 2"><br>
                                <!-- <input type="radio" name="meta_t_radio_<?php echo $page->ID; ?>" value="3">
                                <input type="text" name="meta_title_3_<?php echo $page->ID; ?>" placeholder="Meta Title 3"> -->
                            </div>
                        </div>
                        <!-- Column for meta description -->
                        <div class="col-md-2">
                            <div class="meta-description">
                                <!-- <input type="radio" name="meta_d_radio_<?php echo $page->ID; ?>" value="1"> -->
                                <textarea name="meta_description_1_<?php echo $page->ID; ?>" placeholder="Meta Description 1"><?php echo get_post_meta($page->ID, '_aioseo_description', true); ?></textarea><br>
                                <input type="checkbox" name="meta_d_radio_<?php echo $page->ID; ?>" value="2">
                                <textarea name="meta_description_2_<?php echo $page->ID; ?>" placeholder="Meta Description 2"></textarea><br>
                                <!-- <input type="radio" name="meta_d_radio_<?php echo $page->ID; ?>" value="3">
                                <textarea name="meta_description_3_<?php echo $page->ID; ?>" placeholder="Meta Description 3"></textarea> -->
                            </div>
                        </div>

                        <div class="col-md-2">
                            <p><a href="javascript:void(0);" class="get_alt_tag" data-id="<?php echo $page->ID; ?>" data-type="page">Click here</a></p>
                        </div>

                        <!-- Column for actions related to pages -->
                        <div class="col-md-2">
                            <!-- Action links for viewing and displaying meta info -->
                            <p><a href="admin.php?page=cg_meta_al_view&pgid=<?php echo $page->ID; ?>" class="view-link" data-id="<?php echo $page->ID; ?>" data-type="page" target="_blank">View</a></p>
                            <p><a href="javascript:void(0);" class="fetch_data" data-id="<?php echo $page->ID; ?>">Fetch</a></p>
                            <button class="update-btn" data-page-id="<?php echo $page->ID; ?>">Update</button>
                            <div class="meta-info" style="display: none;" id="mpg_<?php echo $page->ID; ?>">
                                <p class="meta-title"><?php echo get_post_meta($page->ID, '_aioseo_title', true); ?></p>
                                <p class="meta-description"><?php echo get_post_meta($page->ID, '_aioseo_description', true); ?></p>
                            </div>
                        </div>
                      
                        <div id="imgid_<?php echo $page->ID; ?>"></div>
                    </li>
                <?php endforeach; ?>

                <?php
                // Pagination
                $total_pages = ceil(wp_count_posts('page')->publish / 10); // Total number of pages
                echo paginate_links(array(
                    'total' => $total_pages,
                    'current' => $paged,
                ));
                /*$post_types = get_post_types(array('_builtin' => false));

                // Loop through each custom post type and display its name
                foreach ($post_types as $post_type) {

                    if ($post_type != "product") {
                ?>

                        <?php
                        $args = array(
                            'post_type' => $post_type, // Replace 'your_custom_post_type' with the actual custom post type slug
                            'posts_per_page' => 10, // Retrieve all posts
                            'post_status' => 'publish', // Retrieve only published posts
                        );
                        $getcustposts = get_posts($args);

                        foreach ($getcustposts as $cstpost) : ?>
                            <li class="row">
                                <!-- Column for page title -->
                                <div class="col-md-6">
                                    <p><?php echo $cstpost->post_title; ?></p>
                                </div>
                                <!-- Column for actions related to pages -->
                                <div class="col-md-6">
                                    <!-- Action links for viewing and displaying meta info -->
                                    <p><a href="<?php echo get_permalink($cstpost->ID); ?>" class="view-link" data-id="<?php echo $cstpost->ID; ?>" data-type="page" target="_blank">View</a></p>
                                    <div class="meta-info" style="display: none;" id="mpg_<?php echo $cstpost->ID; ?>">
                                        <p class="meta-title"><?php echo get_post_meta($cstpost->ID, '_aioseo_title', true); ?></p>
                                        <p class="meta-description"><?php echo get_post_meta($cstpost->ID, '_aioseo_description', true); ?></p>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; ?>
                <?php }
                } */
                ?>
            </ul>
        </div>

        <!-- Tab content for posts -->
        <div class="tab-pane fade" id="posts" role="tabpanel" aria-labelledby="posts-tab">
            <!-- Heading for post titles and actions -->
            <div class="row">
                <!-- Column for post titles -->
                <div class="col-md-6">
                    <h6>Post Title</h6>
                </div>
                <!-- Column for actions related to posts -->
                <div class="col-md-6">
                    <h6>Action</h6>
                </div>
            </div>
            <!-- Unordered list for displaying post titles -->
            <ul>
                <?php foreach ($posts as $post) : ?>
                    <li class="row">
                        <!-- Column for post title -->
                        <div class="col-md-6">
                            <p><?php echo $post->post_title; ?></p>
                        </div>
                        <!-- Column for actions related to posts -->
                        <div class="col-md-6">
                            <!-- Action links for viewing and displaying meta info -->
                            <p><a href="<?php echo get_permalink($post->ID); ?>" class="view-link" data-id="<?php echo $post->ID; ?>" data-type="post" target="_blank">View</a></p>
                            <div class="meta-info" style="display: none;" id="mpg_<?php echo $post->ID; ?>">
                                <p class="meta-title"><?php echo get_post_meta($post->ID, '_aioseo_title', true); ?></p>
                                <p class="meta-description"><?php echo get_post_meta($post->ID, '_aioseo_description', true); ?></p>
                            </div>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php if (is_plugin_active('woocommerce/woocommerce.php')) {
        ?>
            <!-- Tab content for products -->
            <div class="tab-pane fade" id="products" role="tabpanel" aria-labelledby="products-tab">
                <!-- Heading for products titles and actions -->
                <div class="row">
                    <!-- Column for products titles -->
                    <div class="col-md-6">
                        <h6>Product Name</h6>
                    </div>
                    <!-- Column for actions related to products -->
                    <div class="col-md-6">
                        <h6>Action</h6>
                    </div>
                </div>
                <!-- Unordered list for displaying products titles -->
                <ul>
                    <?php foreach ($products as $product) : ?>
                        <li class="row">
                            <!-- Column for products title -->
                            <div class="col-md-6">
                                <p><?php echo $product->get_name(); ?></p>
                            </div>
                            <!-- Column for actions related to products -->
                            <div class="col-md-6">
                                <!-- Action links for viewing and displaying meta info -->
                                <p><a href="<?php echo $product->get_permalink(); ?>" class="view-link" data-id="<?php echo $product->get_id(); ?>" data-type="product" target="_blank">View</a></p>



                                <div class="meta-info" style="display: none;" id="mpg_<?php echo $product->get_id(); ?>">
                                    <p class="meta-title"><?php echo $product->get_meta('_aioseo_title', true); ?></p>
                                    <p class="meta-description"><?php echo $product->get_meta('_aioseo_description', true); ?></p>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php } ?>
    </div>
</div>

<!-- JavaScript to handle click event of view links -->
<script>
    jQuery(document).ready(function($) {
        // Handle click event of view links
        $('.view-link').click(function(e) {
            e.preventDefault();
            // Hide all previously expanded meta info
            $('.meta-info').hide();
            // Fetch the ID and type of the clicked item
            var id = $(this).data('id');
            // Show the meta info corresponding to the clicked item
            $('#mpg_' + id).toggle();
        });


    });

    jQuery(document).ready(function($) {
        $('.fetch_data').click(function() {

            var pageID = $(this).attr('data-id');

            var pagdescrition = $("#psdes_" + pageID).val();


            var titlechk = "no";
            var deschk = "no";


            var metaTitleRadioButton = $('input[name="meta_t_radio_' + pageID + '"]:checked');

            if (metaTitleRadioButton.length > 0) {
                titlechk = "yes";
            }

            var metaDescriptionRadioButton = $('input[name="meta_d_radio_' + pageID + '"]:checked');
            if (metaDescriptionRadioButton.length > 0) {
                deschk = "yes";
            }

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'fetchmeta_rec',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    titlechk: titlechk,
                    deschk: deschk,
                    //post_des: pagdescrition,
                },
                success: function(response) {
                    var resdata = JSON.parse(response);
                    // console.log(resdata);
                    if (titlechk == 'yes') {
                        var getval = document.querySelector('input[name="meta_title_2_' + pageID + '"]');
                        getval.value = resdata.data.text.meta_title;
                    }
                    if (deschk == 'yes') {
                        var metdesval = document.querySelector('textarea[name="meta_description_2_' + pageID + '"]');
                        metdesval.value = resdata.data.text.meta_description;
                    }
                    //console.log();
                    //console.log(response.data.meta_title);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });


        $('.get_alt_tag').click(function() {
            var pageID = $(this).attr('data-id');

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'getalt_img',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                },
                success: function(response) {
                    var imgtagdta = JSON.parse(response);
                    
                    
                    $("#imgid_" + pageID).html(imgtagdta.data);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        $('.update-btn').click(function() {
            var pageID = $(this).data('page-id');

            // Get the value of the selected radio button for meta title
            var metaTitleRadioButton = $('input[name="meta_t_radio_' + pageID + '"]:checked');
            var mettlval = metaTitleRadioButton.val();
            var metaTitle = $('input[name="meta_title_' + mettlval + '_' + pageID + '"]').val();

            var metaDescriptionRadioButton = $('input[name="meta_d_radio_' + pageID + '"]:checked');
            var medeslval = metaDescriptionRadioButton.val();

            var metaDescription = $('textarea[name="meta_description_' + medeslval + '_' + pageID + '"]').val();
            // console.log(metaTitle);
            // console.log(metaDescription);
            // return false;
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'update_meta_action',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    metaTitle: metaTitle,
                    metaDescription: metaDescription
                },
                success: function(response) {
                    console.log(response);
                    // Update meta info display
                    $('#mpg_' + pageID + ' .meta-title').text(metaTitle);
                    $('#mpg_' + pageID + ' .meta-description').text(metaDescription);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>