<style>
    .loader {
        display: none;
        /* Initially hidden */
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        background-color: #f3f3f3;
        border: 1px solid #ccc;
        border-radius: 5px;
        text-align: center;
        padding: 10px;
        z-index: 9999;
    }

    .progress-container {
        position: relative;
        width: 100%;
        height: 30px;
        background-color: #ddd;
        border-radius: 5px;
        overflow: hidden;
    }

    .progress-bar {
        height: 100%;
        background-color: #4caf50;
        width: 0;
        transition: width 0.5s;
    }

    .percentage-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        margin: 0;
        font-size: 16px;
        color: #fff;
    }
</style>
<?php

function get_post_description($post_id)
{
    $post = get_post($post_id);
    if ($post) {
        // Get the post content and strip HTML tags
        $description = wp_strip_all_tags($post->post_content);
        return $description;
    }
    return false;
}

$aifilterpage = isset($_GET['aifilterpage']) ? $_GET['aifilterpage'] : 10; // Current page number
?>



<div class="overlay" id="overlay"></div>
<div class="flexButtonsCg">
    <div class="gridFlexCg">
        <ul class="buttonsCg">
            <li><a id="pages-tab" href="admin.php?page=cg_meta_al_list" class="normalBtnCG normalBtnCGV2">Pages</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_product" class="normalBtnCG ">Products</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_altag" class="normalBtnCG normalBtnCGV2">Alt Tags</a></li>

        </ul>
    </div>

    <!-- <div class="gridFlexCg justifyRight">
        <ul class="buttonsCg">
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_gen">Generate Bulk Information</a></li>
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_update">Update Bulk Information</a></li>
        </ul>
    </div> -->
</div>

<div class="flexButtonsCg" style="margin-top:5px;">
    <div class="gridFlexCg">
        <select id="page_filter" onchange="call_filter();">
            <option value="">select filter</option>
            <option <?php if ($aifilterpage == 10) { ?> selected <?php } ?> value="10">10</option>
            <option <?php if ($aifilterpage == 30) { ?> selected <?php } ?> value="30">30</option>
            <option <?php if ($aifilterpage == 50) { ?> selected <?php } ?> value="50">50</option>
        </select>
    </div>
    <div class="gridFlexCg justifyRight">
        <span id="token_usgae"></span>
    </div>

</div>


<div class="tableStCg" class="tab-pane fade show active" id="pages" role="tabpanel" aria-labelledby="pages-tab">
    <div class="scrollTable">
        <div class="bgAreaGray37">
            <table cellpadding="0" cellspacing="0">
                <tbody>

                    <tr class="flexDs">

                        <td class="wd30s noBGColor noBGColor2">
                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                <tbody>
                                    <tr>
                                        <td><b>Page Title</b></td>
                                        <td><b>URLs</b></td>
                                    </tr>



                                </tbody>
                            </table>

                        </td>

                        <td class="wd70s noBGColor noBGColor2">
                            <table cellpadding="0" cellspacing="0">
                                <tbody>
                                    <tr class="rightFlexForm">
                                        <td class="wd80s">
                                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                                <tbody>
                                                    <tr class="flexWdTd">
                                                        <td><label class="containerCheckmark"><b>Meta Title</b><!--<input type="checkbox" class="meta_titl_desc" name="meta_titl"><span class="checkmark"></span>--></label></td>
                                                        <td><label class="containerCheckmark"><b>Meta Description</b><!--<input type="checkbox" class="meta_desc" name="meta_des"><span class="checkmark"></span>--></label></td>

                                                    </tr>

                                                </tbody>
                                            </table>

                                        </td>


                                        <td class="wd20s">
                                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                                <tbody>
                                                    <tr>

                                                        <td><b>Action<b></td>

                                                    </tr>
                                                </tbody>
                                            </table>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>


                    </tr>
                </tbody>
            </table>
        </div>
        <div class="borderSeparate">
            <?php

            //foreach ($pages as $page) :

            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number

            $args = array(
                'post_type' => 'product', // Include both posts and pages
                'post_status' => 'publish', // Only published posts/pages
                'posts_per_page' => $aifilterpage, // Limiting to 10 posts/pages per page
                'offset' => ($paged - 1) * $aifilterpage, // Offset calculation
            );
            $query = new WP_Query($args);
            while ($query->have_posts()) : $query->the_post();

                //$post_description = get_post_description($page->ID);
                //$allpostmeta = get_post_meta($post_id);
                // echo"<pre>"; print_r($allpostmeta); echo "</pre>";
                $post_id = get_the_ID();

                $seo_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
                $seo_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
                if ($plgactive == "cg_aioseo") {
                    $seo_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
                    $seo_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
                } else if ($plgactive == "cg_yoast") {
                    $seo_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
                    $seo_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
                } else if ($plgactive == "cg_rank_math") {
                    $seo_title = get_post_meta($post_id, 'rank_math_title', true);
                    $seo_description = get_post_meta($post_id, 'rank_math_description', true);
                }
            ?>

                <div class="bgAreaGray37">


                    <table cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr class="flexDs">

                                <td class="wd30s noBGColor">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="titLeLink titLeLinkWeight500"><?php the_title(); ?></a>
                                                </td>
                                                <td>
                                                    <div class="titLeLink"><a href="<?php the_permalink(); ?>"><?php the_permalink(); ?></a></div>
                                                </td>
                                            </tr>



                                        </tbody>
                                    </table>

                                </td>
                                <td class="wd70s noBGColor">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr class="rightFlexForm">
                                                <td class="wd80s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild PDleft22"><textarea name="meta_title_1_<?php echo $post_id; ?>" readonly><?php echo esc_html($seo_title); ?></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild PDleft22">
                                                                            <div class="textareaType">
                                                                                <textarea name="meta_des_1_<?php echo $post_id; ?>" id="meta_des_1_<?php echo $post_id; ?>" readonly><?php echo esc_html($seo_description); ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                        </tbody>
                                                    </table>

                                                </td>


                                                <td class="wd20s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>

                                                                <td class="centerAppBtn">
                                                                </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>


                            </tr>

                            <tr>
                                <td>
                                    <h5>focus keywords</h5>
                                </td>
                            </tr>
                            <tr class="flexDs">

                                <td class="wd30s">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="flexCheckCg flexCheckCgNoFlex">
                                                        <div class="flexCheckCgChild"><textarea name="meta_focus_<?php echo $post_id; ?>" class="postp_title" placeholder="Enter you focus with comma seprated"></textarea></div>
                                                    </div>
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>

                                </td>

                                <td class="wd70s">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr class="rightFlexForm">
                                                <td class="wd80s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="0" name="meta_t_chk_2_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_2_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="0" name="meta_d_2_chkd_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_2_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="1" name="meta_t_chk_3_<?php echo $post_id; ?>" value="3"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_3_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="1" name="meta_d_3_chkd_<?php echo $post_id; ?>" value="3"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_3_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="2" name="meta_t_chk_4_<?php echo $post_id; ?>" value="4"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_4_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="2" name="meta_d_4_chkd_<?php echo $post_id; ?>" value="4"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_4_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>

                                                <input type="hidden" id="regen_<?php echo $post_id; ?>" value="">
                                                <td class="wd20s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>

                                                                <td class="centerAppBtn">
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH clickToExpand fetch_data" data-id="<?php echo $post_id; ?>">Generate</button></div>
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH blueBtncg update-btn" data-page-id="<?php echo $post_id; ?>">Update</button></div>
                                                                </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>







                            </tr>
                        </tbody>
                    </table>

                </div>
                <div class="activeExCgtable paddingAreaCg" id="main_imgid_<?php echo $post_id; ?>" style="display: none;">
                    <div class="activeExCgtableH6">
                        <h6>Alt Tags Generation</h6>
                        <div class="gridFlexCG" id="imgid_<?php echo $post_id; ?>">



                        </div>
                    </div>
                </div>
            <?php //endforeach;

            endwhile;
            // Restore original Post Data
            // Pagination

            ?>
        </div>
        <?php

        function my_custom_admin_pagination($total_pages, $current_page, $base_url)
        {
            // Generate pagination links
            $pagination_links = paginate_links(array(
                'base'      => add_query_arg('paged', '%#%', $base_url),
                'format'    => '',
                'current'   => $current_page,
                'total'     => $total_pages,
                'mid_size'  => 2,
                'prev_text' => __('« Previous'),
                'next_text' => __('Next »'),
                'type'      => 'array', // Generate as array to modify links
            ));

            if ($pagination_links) {
                echo '<ul class="pagination">'; // Open pagination container

                // Loop through pagination links and add custom classes
                foreach ($pagination_links as $link) {
                    // Check if the link is the current page
                    if (strpos($link, 'current') !== false) {
                        echo '<li class="page-item active">' . str_replace('page-numbers', 'page-link', $link) . '</li>';
                    } else {
                        echo '<li class="page-item">' . str_replace('page-numbers', 'page-link', $link) . '</li>';
                    }
                }

                echo '</ul>'; // Close pagination container
            }
        }

        // Get the total number of published pages        
        // Get the total number of products (assuming you are querying custom posts or products)
        $total_products = wp_count_posts('product')->publish; // Replace 'product' with your post type
        $total_pages = ceil($total_products / $aifilterpage);

        // Get the current page number
        $current_page = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number

        // Construct the base URL for pagination (preserve other query parameters)
        $base_url = admin_url('admin.php?page=cg_meta_al_product&aifilterpage=' . $aifilterpage);

        if ($total_pages > 1) {
            echo '<div class="flexDirectionCg">'; // Opening div tag
            my_custom_admin_pagination($total_pages, $current_page, $base_url);
            echo '</div>'; // Closing div tag
        }

        wp_reset_postdata(); // Reset post data to the main query
        ?>
    </div>
</div>


<!-- JavaScript to handle click event of view links -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    //code for check all checkbox for meta title 
    $("body").on("click", ".meta_titl_desc", function() {

        if ($(this).prop("checked")) {
            $(".title_checkbox").prop("checked", true);
        } else {
            $(".title_checkbox").prop("checked", false);
        }

    });

    //code for check all checkbox for meta descritption 
    $("body").on("click", ".meta_desc", function() {

        if ($(this).prop("checked")) {
            $(".meta_des_box").prop("checked", true);
        } else {
            $(".meta_des_box").prop("checked", false);
        }

    });


    // Function to display success message in a popup
    function showSuccessPopup(message) {
        // Create a new element for the popup message
        var popup = document.createElement('div');
        popup.innerHTML = '<div class="updatedDataNow">' +
            '<p>' + message + '</p>' +
            '<button id="closeButton">Close</button>' +
            '</div>';

        // Style the popup element
        popup.style.position = 'fixed';
        popup.style.top = '50%';
        popup.style.left = '50%';
        popup.style.transform = 'translate(-50%, -50%)';
        popup.style.backgroundColor = 'rgb(0 0 0 / 27%)';
        popup.style.border = '1px solid #cccccc';
        popup.style.padding = '20px';
        popup.style.zIndex = '10000';
        popup.style.width = '100%';
        popup.style.height = '100%';

        // Append the popup to the body
        document.body.appendChild(popup);

        // Close the popup when the close button is clicked
        var closeButton = document.getElementById('closeButton');
        closeButton.addEventListener('click', function() {
            document.body.removeChild(popup);
        });
    }

    jQuery(document).ready(function($) {


        // Handle click event of view links
        $('.view-link').click(function(e) {
            e.preventDefault();
            // Hide all previously expanded meta info
            $('.meta-info').hide();
            // Fetch the ID and type of the clicked item
            var id = $(this).data('id');
            // Show the meta info corresponding to the clicked item
            $('#mpg_' + id).toggle();
        });


    });

    jQuery(document).ready(function($) {
        $('.fetch_data').click(function() {

            // Get the page ID from the data-id attribute of the clicked element
            var pageID = $(this).attr('data-id');
            // Get the page description value from the corresponding textarea
            var pagdescrition = $("#psdes_" + pageID).val();
            var titlechk = "no";
            var deschk = "no";

            // Check if the meta title radio button is checked
            var metaTitleRadioButton = $('input[name="metapretitle_' + pageID + '"]:checked');
            if (metaTitleRadioButton.length > 0) {
                titlechk = "yes";
            }

            // Check if the meta description radio button is checked
            var metaDescriptionRadioButton = $('input[name="metapredescription_' + pageID + '"]:checked');
            if (metaDescriptionRadioButton.length > 0) {
                deschk = "yes";
            }

            // If neither title nor description is checked, set both to "yes"
            if (titlechk == "no" && deschk == "no") {
                titlechk = "yes";
                deschk = "yes";
            }

            // Get the value of the regeneration checkbox
            var chkregen = $("#regen_" + pageID).val();

            // Get the value of the focus keyword textarea
            var foukeyword = $('textarea[name="meta_focus_' + pageID + '"]').val();

             // Show the custom loader
            jQuery('#custom-loader_cust').addClass('show');

             // Send an AJAX request to the server
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'fetchmeta_rec',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    titlechk: titlechk,
                    foukeyword: foukeyword,
                    deschk: deschk,

                },
                success: function(response) {
                     // Hide the custom loader
                    jQuery('#custom-loader_cust').removeClass('show');
                    var resdata = JSON.parse(response);
                    if (resdata.msg == "disconnect") {

                        showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                    } else if (resdata.msg == "request_limit") {
                        alert('Request limit reached');
                    } else if (resdata.msg == "invalid") {
                        alert('Invalid user');
                    } else {
                        $("#regen_" + pageID).val(1);
                        if (titlechk == 'yes') {

                            if (chkregen != "") {
                                // Loop through checked pre-title checkboxes and update the corresponding textareas
                                $('.pre_title_checkbox:checked').each(function() {

                                    var getvalue = $(this).attr('reqatt');
                                    console.log(getvalue);

                                    var mettlename = $(this).attr('name');
                                    var splitcrtd = mettlename.split("_");
                                    if (resdata.data == "not_found") {
                                        $('textarea[name="meta_title_' + splitcrtd[3] + '_' + pageID + '"]').val('not_found');
                                    } else {
                                        $('textarea[name="meta_title_' + splitcrtd[3] + '_' + pageID + '"]').val(resdata.data.text.meta_title[getvalue]);
                                    }


                                });

                            } else {

                                if (resdata.data == "not_found") {
                                    var getval1 = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                    getval1.value = "not_found";

                                    var getval2 = document.querySelector('textarea[name="meta_title_3_' + pageID + '"]');
                                    getval2.value = "not_found";


                                    var getval3 = document.querySelector('textarea[name="meta_title_4_' + pageID + '"]');
                                    getval3.value = "not_found";
                                } else {
                                    var getval1 = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                    getval1.value = resdata.data.text.meta_title[0];

                                    var getval2 = document.querySelector('textarea[name="meta_title_3_' + pageID + '"]');
                                    getval2.value = resdata.data.text.meta_title[1];


                                    var getval3 = document.querySelector('textarea[name="meta_title_4_' + pageID + '"]');
                                    getval3.value = resdata.data.text.meta_title[2];
                                }
                            }
                        }
                        // Update meta descriptions if deschk is 'yes'
                        if (deschk == 'yes') {

                            if (chkregen != "") {

                                $('.pre_des_chk:checked').each(function() {

                                    var getvalue = $(this).attr('desreqatt');

                                    var mettlename = $(this).attr('name');
                                    var splitcrtd = mettlename.split("_");
                                    console.log(splitcrtd);
                                    if (resdata.data == "not_found") {
                                        $('textarea[name="meta_des_' + splitcrtd[2] + '_' + pageID + '"]').val('not_found');
                                    } else {
                                        $('textarea[name="meta_des_' + splitcrtd[2] + '_' + pageID + '"]').val(resdata.data.text.meta_description[getvalue]);
                                    }

                                });

                            } else {

                                if (resdata.data == "not_found") {
                                    var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                    metdesval1.value = "not_found";

                                    var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                    metdesval2.value = "not_found";

                                    var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                    metdesval3.value = "not_found";

                                } else {
                                    var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                    metdesval1.value = resdata.data.text.meta_description[0];

                                    var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                    metdesval2.value = resdata.data.text.meta_description[1];

                                    var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                    metdesval3.value = resdata.data.text.meta_description[2];
                                }
                            }
                        }
                        get_request_limit();
                    }


                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });

        });


        $('.get_alt_tag').click(function() {
            var pageID = $(this).attr('data-id');
            // Show WordPress admin default spinner
            jQuery('#custom-loader').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'getalt_img',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                },
                success: function(response) {
                    jQuery('#custom-loader').removeClass('show');
                    var imgtagdta = JSON.parse(response);
                    $("#main_imgid_" + pageID).css('display', 'inline-block');
                    $("#imgid_" + pageID).html(imgtagdta.data);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                },
                complete: function() {
                    // Hide WordPress admin default spinner
                    jQuery('#custom-loader').removeClass('show');
                }
            });
        });


        $('.update-btn').click(function() {
            var pageID = $(this).data('page-id');            

            var titlechk = "no";
            var deschk = "no";

            var getseletddom = $('.pre_title_checkbox:checked');
            if (getseletddom.length > 1) {
                alert('Please select single meta title and description to update on your web page');
                return false;
            }

            if (getseletddom.length == 1) {
                titlechk = "yes";
            }

            var getdesc = $('.pre_des_chk:checked');
            if (getdesc.length > 1) {
                alert('Please select single meta title and description to update on your web page');
                return false;
            }

            var metaTitle = "";
            if (titlechk == "yes") {
                var mettlename = getseletddom.attr('name');

                var splitcrtd = mettlename.split("_");

                metaTitle = $('textarea[name="meta_title_' + splitcrtd[3] + '_' + pageID + '"]').val();
            }

            if (getdesc.length == 1) {
                deschk = "yes";
            }
            var metaDescriptiontxt = "";
            if (deschk == "yes") {
                var metades = getdesc.attr('name');
                var splitcrtd2 = metades.split("_");
                console.log(splitcrtd2)
                metaDescriptiontxt = $('textarea[name="meta_des_' + splitcrtd2[2] + '_' + pageID + '"]').val();
            }

            jQuery('#custom-loader_cust').addClass('show');

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'update_meta_action',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    metaTitle: metaTitle,
                    metaDescription: metaDescriptiontxt
                },
                success: function(response) {
                    jQuery('#custom-loader_cust').removeClass('show');
                    // Update meta info display
                    showSuccessPopup('Updated Successfully');

                    if (titlechk == 'yes') {
                        var getval = document.querySelector('textarea[name="meta_title_1_' + pageID + '"]');
                        getval.value = metaTitle;
                    }
                    if (deschk == 'yes') {
                        var descsdr = document.querySelector('textarea[name="meta_des_1_' + pageID + '"]');
                        descsdr.value = metaDescriptiontxt;

                    }

                    $('#mpg_' + pageID + ' .meta-title').text(metaTitle);
                    $('#mpg_' + pageID + ' .meta-description').text(metaDescriptiontxt);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        // Add a click event handler for the submit button of each form
        $(document).on('click', '.alt_sub', function(e) {
            e.preventDefault(); // Prevent default form submission
            
            var form = $(this).closest('form');
            jQuery('#custom-loader').addClass('show');
            // Serialize the form data
            var formData = form.serialize();

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'update_image_alt_text',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    fromdata: formData,
                }, // Form data
                success: function(response) {
                    jQuery('#custom-loader').removeClass('show');
                    showSuccessPopup('Updated Successfully');
                    
                    // Optionally, you can handle success response
                },
                error: function(xhr, status, error) {
                    alert('Error occurred while updating alt tags.');
                    // Optionally, you can handle error response
                }
            });
        });        

        $('.bulk_gen').click(function() {

            var check_title = "no";
            var check_des = "no";
            if ($(".meta_titl_desc").prop("checked")) {
                check_title = "yes";
            }

            if ($(".meta_desc").prop("checked")) {
                check_des = "yes";
            }

            var title_selctbox = [];
            var descr_selctbox = [];

            // Iterate over each checkbox with class "title_checkbox"
            $('.title_checkbox').each(function() {
                // Check if the checkbox is checked
                if ($(this).prop('checked')) {
                    // If checked, push its name to the selectedCheckboxes array
                    title_selctbox.push($(this).attr('name'));
                }
            });

           
            $('.meta_des_box').each(function() {
                // Check if the checkbox is checked
                if ($(this).prop('checked')) {
                    // If checked, push its name to the selectedCheckboxes array
                    descr_selctbox.push($(this).attr('name'));
                }
            });
            
            var titelnt = title_selctbox.length;
            var desclen = descr_selctbox.length;
            var sumtoken = titelnt + desclen;
            alert('You are consuming ' + sumtoken + ' tokens');
            jQuery('#custom-loader_cust').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'bulk_meta_genrate',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    p_meta_t: title_selctbox,
                    p_meta_d: descr_selctbox,
                    gettype_title: check_title,
                    gettype_desc: check_des
                    
                },
                success: function(response) {
                    jQuery('#custom-loader_cust').removeClass('show');
                    var resdata = JSON.parse(response);

                    if (resdata.msg == "disconnect") {
                        showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                    } else if (resdata.msg == "request_limit") {
                        showSuccessPopup('Request limit reached');
                    } else if (resdata.msg == "insuffconnect") {
                        showSuccessPopup('You have insufficient connect for request');
                    } else {
                        if (check_title == 'yes' && check_des == 'no') {
                            for (var key_title in resdata) {
                                var pstid = key_title;
                                var title_text = resdata[key_title].gen_ai;
                                var getval = document.querySelector('textarea[name="meta_title_2_' + pstid + '"]');
                                getval.value = title_text;

                            }

                        } else if (check_des == 'yes' && check_title == 'no') {
                            for (var key_des in resdata) {
                                var pstid = key_des;
                                var dwesxtext = resdata[key_des].gen_ai;
                                console.log(pstid);
                                var getvaldes = document.querySelector('textarea[name="meta_description_2_' + pstid + '"]');
                                if (getvaldes) {
                                    getvaldes.value = dwesxtext || "";
                                }

                            }

                        } else if (check_des == 'yes' && check_title == 'yes') {
                            for (const key in resdata) {
                                const pstid = key;
                                const pos_titl = resdata[key].gen_ai_title;
                                const pos_titdesc = resdata[key].gen_ai_description;
                                var getval_title = document.querySelector('textarea[name="meta_title_2_' + pstid + '"]');
                                var getval_desc = document.querySelector('textarea[name="meta_description_2_' + pstid + '"]');
                                getval_title.value = pos_titl;
                                if (getval_desc) {
                                    getval_desc.value = pos_titdesc || "";
                                }

                            }

                        }
                        get_request_limit();
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });

        });

        $('.bulk_update').click(function() {

            var check_title = "no";
            var check_des = "no";
            if ($(".meta_titl_desc").prop("checked")) {
                check_title = "yes";
            }

            if ($(".meta_desc").prop("checked")) {
                check_des = "yes";
            }

            var title_selctbox = [];
            var descr_selctbox = [];

            // Iterate over each checkbox with class "title_checkbox"
            $('.postp_title').each(function() {
                var tlname = $(this).attr('name');
                var prtids = tlname.split('_');
                var pstids = prtids[3];
                title_selctbox.push({
                    [pstids]: $(this).val()
                });


            });


            $('.postp_des').each(function() {
                // Check if the checkbox is checked
                // If checked, push its name to the selectedCheckboxes array
                var desname = $(this).attr('name');
                var desprtids = desname.split('_');
                var dspstids = desprtids[3];

                descr_selctbox.push({
                    [dspstids]: $(this).val()
                });

            });

           
            jQuery('#custom-loader_cust').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'bulk_update_meta',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    p_meta_t: title_selctbox,
                    p_meta_d: descr_selctbox,
                    gettype_title: check_title,
                    gettype_desc: check_des
                   
                },
                success: function(response) {
                    jQuery('#custom-loader_cust').removeClass('show');
                    if (check_title == 'yes') {
                        $('.postp_title').each(function() {
                            var tlname = $(this).attr('name');
                            var prtids = tlname.split('_');
                            var pstids = prtids[3];

                            var getval = document.querySelector('textarea[name="meta_title_1_' + pstids + '"]');
                            getval.value = $(this).val();

                        });
                    }
                    if (check_des == 'yes') {
                        $('.postp_des').each(function() {
                            var tlname = $(this).attr('name');
                            var prtids = tlname.split('_');
                            var pstids = prtids[3];
                            var getval = document.querySelector('textarea[name="meta_des_1_' + pstids + '"]');
                            getval.value = $(this).val();

                        });
                    }

                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });

        });

    });

    function call_filter() {
        var selectElement = document.getElementById("page_filter");
        var selectedValue = selectElement.value;
       
        if (selectedValue != "") {
            // Adding parameter to the URL
            var paramName = "aifilterpage";
            var paramValue = selectedValue;
            addParameterToURL(paramName, paramValue);
        }
    }

    // Function to add a parameter to the URL
    function addParameterToURL(paramName, paramValue) {
        var url = window.location.href;

        // Check if the URL already contains parameters
        if (url.indexOf('?') !== -1) {
            // URL already contains parameters
            url += '&' + paramName + '=' + paramValue;
        } else {
            // URL does not contain parameters
            url += '?' + paramName + '=' + paramValue;
        }

        // Redirect to the updated URL
        window.location.href = url;
    }

    function get_request_limit() {

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'fetch_req_limit',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
            },
            success: function(response) {
                var resdata = JSON.parse(response);
                if (resdata.msg == "disconnect") {
                    jQuery(".fetch_data").remove();
                    jQuery(".bulk_gen").remove();
                   
                } else {
                    jQuery("#token_usgae").html("Token Usage: <strong>" + resdata.request_limit + "/" + resdata.total_limit + "</strong");
                }

            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });

    }
    get_request_limit();
</script>