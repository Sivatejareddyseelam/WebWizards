<?php
$retrieved_license_key = get_option('license_key_ai');
?>
<div class="flexLogin">
    <div class="flexLoginChild flexLoginChild70">
        <div class="welcomeLogin welcomeProfile">
            <h5>Activation Key</h5>
            <div class="maxwd415">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
            </div>

            <div class="d-lg-flex half loginFormTop activationKey">
                <div class="contents order-2 order-md-1">
                    <form id="sub_key" method="post">
                        <div class="form-group first">
                            <input type="text" class="form-control" name="license_key" placeholder="Enter License Key" <?php if ($retrieved_license_key != "") { ?> value="************" <?php } ?>>
                        </div>
                        <?php //if ($retrieved_license_key == "") { ?>
                            <input type="submit" value="Apply" class="btn btn-block btn-primary track_license">
                        <?php //} ?>
                        <span id="key_msg"></span>
                    </form>
                </div>
            </div>


        </div>

    </div>
    <div class="flexLoginChild">

        <div class="imageLogoMeta imageLogoMetaCenter"><img src="images/logV2.png" /></div>
        <div class="infoCG67New">
            <h5>Quis autem vel eum iure reprehenderit</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
        </div>

    </div>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
    $(document).on('click', '.track_license', function(e) {
        e.preventDefault(); // Prevent default form submission
        //alert('sss');
        var form = $(this).closest('form');
        jQuery('#custom-loader').addClass('show');
        // Serialize the form data
        var formData = form.serialize();

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'validate_license_key',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                fromdata: formData,
            }, // Form data
            success: function(response) {
                jQuery('#custom-loader').removeClass('show');
                var resdata = JSON.parse(response);
                if (resdata.msg == "success") {
                    jQuery('#key_msg').html('Plugin activated successfully');
                } else if (resdata.msg == "disconnect") {
                    jQuery('#key_msg').html('Disconnect License Key');
                } else {
                    jQuery('#key_msg').html('Invalid License Key');
                }
            },
            error: function(xhr, status, error) {
                alert('Error occurred while updating alt tags.');
                // Optionally, you can handle error response
            }
        });
    });
</script>