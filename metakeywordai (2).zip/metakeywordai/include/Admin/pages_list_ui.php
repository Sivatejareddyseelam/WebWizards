<?php
$aifilterpage = isset($_GET['aifilterpage']) ? $_GET['aifilterpage'] : 10; // Current page number
?>


<style>

</style>




<div class="flexButtonsCg">
    <div class="gridFlexCg">
        <ul class="buttonsCg">
            <li><a id="pages-tab" href="admin.php?page=cg_meta_al_list" class="normalBtnCG">Pages</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_product" class="normalBtnCG normalBtnCGV2">Products</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_altag" class="normalBtnCG normalBtnCGV2">Alt Tags</a></li>

        </ul>
    </div>


    <!-- <div class="gridFlexCg justifyRight">
        <ul class="buttonsCg">
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_gen">Generate Bulk Information</a></li>
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_update">Update Bulk Information</a></li>
        </ul>
    </div> -->
</div>

<div class="flexButtonsCg" style="margin-top:5px;">

    <div class="gridFlexCg ">
        <ul class="buttonsCg">
            <li><select id="page_filter" onchange="call_filter();">
                    <option value="">select filter</option>
                    <option <?php if ($aifilterpage == 10) { ?> selected <?php } ?> value="10">10</option>
                    <option <?php if ($aifilterpage == 30) { ?> selected <?php } ?> value="30">30</option>
                    <option <?php if ($aifilterpage == 50) { ?> selected <?php } ?> value="50">50</option>
                </select></li>
        </ul>
    </div>
    <div class="gridFlexCg justifyRight">
        <ul class="buttonsCg">
            <li><span id="token_usgae"></span></li>
        </ul>
    </div>


</div>

<div class="tableStCg" class="tab-pane fade show active" id="pages" role="tabpanel" aria-labelledby="pages-tab">

    <div class="scrollTable">

        <div class="bgAreaGray37">
            <table cellpadding="0" cellspacing="0">
                <tbody>

                    <tr class="flexDs">

                        <td class="wd30s noBGColor noBGColor2">
                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                <tbody>
                                    <tr>
                                        <td><b>Page Title</b></td>
                                        <td><b>URLs</b></td>
                                    </tr>



                                </tbody>
                            </table>

                        </td>

                        <td class="wd70s noBGColor noBGColor2">
                            <table cellpadding="0" cellspacing="0">
                                <tbody>
                                    <tr class="rightFlexForm">
                                        <td class="wd80s">
                                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                                <tbody>
                                                    <tr class="flexWdTd">
                                                        <td><label class="containerCheckmark"><b>Meta Title</b><!--<input type="checkbox" class="meta_titl_desc" name="meta_titl"><span class="checkmark"></span>--></label></td>
                                                        <td><label class="containerCheckmark"><b>Meta Description</b><!--<input type="checkbox" class="meta_desc" name="meta_des"><span class="checkmark"></span>--></label></td>

                                                    </tr>

                                                </tbody>
                                            </table>

                                        </td>


                                        <td class="wd20s">
                                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                                <tbody>
                                                    <tr>

                                                        <td><b>Action<b></td>

                                                    </tr>
                                                </tbody>
                                            </table>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>


                    </tr>
                </tbody>
            </table>
        </div>
        <div class="borderSeparate">



            <?php

            // Get the current page number from the query string, default to 1 if not set
            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1;

            // Arguments for the WP_Query to fetch posts and pages
            $args = array(
                'post_type' => array('post', 'page'), // Include both posts and pages
                'post_status' => 'publish', // Only published posts/pages
                'posts_per_page' => $aifilterpage, // Limiting to 10 posts/pages per page (variable $aifilterpage)
                'offset' => ($paged - 1) * $aifilterpage, // Offset calculation based on current page
            );

            // Create a new WP_Query instance with the specified arguments
            $query = new WP_Query($args);

            // Loop through the posts/pages retrieved by the query

            $il = 1;
            while ($query->have_posts()) : $query->the_post();
                // Get the ID of the current post/page
                $post_id = get_the_ID();

                // Initialize variables for SEO title and description
                $seo_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
                $seo_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);

                // Check which SEO plugin is active and get the corresponding meta values
                if ($plgactive == "cg_aioseo") {
                    $seo_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
                    $seo_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
                } else if ($plgactive == "cg_yoast") {
                    $seo_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
                    $seo_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
                } else if ($plgactive == "cg_rank_math") {
                    $seo_title = get_post_meta($post_id, 'rank_math_title', true);
                    $seo_description = get_post_meta($post_id, 'rank_math_description', true);
                }

                if ($il == 1) {
                    $activsl = "active";
                    $displaysty = "display:block;";
                } else {
                    $activsl = "";
                    $displaysty = "display:none;";
                }

            ?>



                <!---------------------------->
                <button ids="<?php echo $il; ?>" class="accordionBtn <?php echo $activsl; ?>"><?php the_title(); ?></button>
                <div class="bgAreaGray37 panel" style="<?php echo $displaysty; ?>">

                    <table cellpadding="0" cellspacing="0">
                        <tbody>



                            <tr class="flexDs">

                                <td class="wd30s noBGColor">

                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="titLeLink titLeLinkWeight500"><?php the_title(); ?></a>
                                                </td>
                                                <td>
                                                    <div class="titLeLink"><a href="<?php the_permalink(); ?>"><?php the_permalink(); ?></a></div>
                                                </td>
                                            </tr>



                                        </tbody>
                                    </table>

                                </td>

                                <td class="wd70s noBGColor">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr class="rightFlexForm">
                                                <td class="wd80s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="title_checkbox" name="metapretitle_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea name="meta_title_1_<?php echo $post_id; ?>" readonly><?php echo esc_html($seo_title); ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="title_checkbox" name="metapredescription_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22">
                                                                            <textarea name="meta_des_1_<?php echo $post_id; ?>" id="meta_des_1_<?php echo $post_id; ?>" readonly><?php echo esc_html($seo_description); ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                        </tbody>
                                                    </table>

                                                </td>


                                                <td class="wd20s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>

                                                                <td class="centerAppBtn">
                                                                </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>







                            </tr>
                            <tr>
                                <td>
                                    <h5>focus keywords</h5>
                                </td>
                            </tr>
                            <tr class="flexDs">

                                <td class="wd30s">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="flexCheckCg flexCheckCgNoFlex">
                                                        <div class="flexCheckCgChild"><textarea name="meta_focus_<?php echo $post_id; ?>" class="postp_title" placeholder="Enter you focus with comma seprated"></textarea></div>
                                                    </div>
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>

                                </td>

                                <td class="wd70s">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr class="rightFlexForm">
                                                <td class="wd80s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="0" name="meta_t_chk_2_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_2_<?php echo $post_id; ?>" placeholder=""></textarea></div>

                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="0" name="meta_d_2_chkd_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_2_<?php echo $post_id; ?>" placeholder=""></textarea></div>

                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="1" name="meta_t_chk_3_<?php echo $post_id; ?>" value="3"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_3_<?php echo $post_id; ?>" placeholder=""></textarea></div>

                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="1" name="meta_d_3_chkd_<?php echo $post_id; ?>" value="3"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_3_<?php echo $post_id; ?>" placeholder=""></textarea></div>

                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr class="flexWdTd">
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="2" name="meta_t_chk_4_<?php echo $post_id; ?>" value="4"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_4_<?php echo $post_id; ?>" placeholder=""></textarea></div>

                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="2" name="meta_d_4_chkd_<?php echo $post_id; ?>" value="4"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_4_<?php echo $post_id; ?>" placeholder=""></textarea></div>

                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>

                                                <input type="hidden" id="regen_<?php echo $post_id; ?>" value="">
                                                <td class="wd20s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>

                                                                <td class="centerAppBtn">
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH clickToExpand fetch_data" typattrb="meta_titlegt" data-id="<?php echo $post_id; ?>">Get title</button></div>
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH clickToExpand fetch_data" typattrb="meta_descgt" data-id="<?php echo $post_id; ?>">Get description</button></div>
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH clickToExpand fetch_data" typattrb="meta_both" data-id="<?php echo $post_id; ?>">Get both</button></div>
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH blueBtncg update-btn" data-page-id="<?php echo $post_id; ?>">Update</button></div>
                                                                </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>







                            </tr>

                        </tbody>
                    </table>
                </div>
                <!------------------------------>

            <?php //endforeach;
                $il = $il + 1;
            endwhile;
            // Restore original Post Data
            wp_reset_postdata();
            ?>
        </div>
        <?php

        // Get the total number of published pages
        $total_pages = ceil(wp_count_posts('page')->publish / $aifilterpage);

        // Get the current page number
        // $paged = max(1, get_query_var('paged', 1));
        $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number

        // Check if there's more than one page
        if ($total_pages > 1) {
            echo '<div class="flexDirectionCg">'; // Opening div tag

            // Generate pagination links
            echo paginate_links(array(
                'base'      => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                'format'    => '?paged=%#%',
                'current'   => $paged,
                'total'     => $total_pages,
                'mid_size'  => 2,
                'prev_text' => __('« Previous'),
                'next_text' => __('Next »'),
            ));

            echo '</div>'; // Closing div tag
        }

        ?>

    </div>
</div>


<!-- JavaScript to handle click event of view links -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    //code for check all checkbox for meta title 
    $("body").on("click", ".meta_titl_desc", function() {

        if ($(this).prop("checked")) {
            $(".title_checkbox").prop("checked", true);
        } else {
            $(".title_checkbox").prop("checked", false);
        }

    });

    //code for check all checkbox for meta descritption 
    $("body").on("click", ".meta_desc", function() {

        if ($(this).prop("checked")) {
            $(".meta_des_box").prop("checked", true);
        } else {
            $(".meta_des_box").prop("checked", false);
        }

    });


    // Function to display success message in a popup
    function showSuccessPopup(message) {
        // Create a new element for the popup message
        var popup = document.createElement('div');
        popup.innerHTML = '<div class="updatedDataNow">' +
            '<p>' + message + '</p>' +
            '<button id="closeButton">Close</button>' +
            '</div>';

        // Style the popup element
        popup.style.position = 'fixed';
        popup.style.top = '50%';
        popup.style.left = '50%';
        popup.style.transform = 'translate(-50%, -50%)';
        popup.style.backgroundColor = 'rgb(0 0 0 / 27%)';
        popup.style.border = '1px solid #cccccc';
        popup.style.padding = '20px';
        popup.style.zIndex = '10000';
        popup.style.width = '100%';
        popup.style.height = '100%';

        // Append the popup to the body
        document.body.appendChild(popup);

        // Close the popup when the close button is clicked
        var closeButton = document.getElementById('closeButton');
        closeButton.addEventListener('click', function() {
            document.body.removeChild(popup);
        });
    }

    jQuery(document).ready(function($) {


        // Handle click event of view links
        $('.view-link').click(function(e) {
            e.preventDefault();
            // Hide all previously expanded meta info
            $('.meta-info').hide();
            // Fetch the ID and type of the clicked item
            var id = $(this).data('id');
            // Show the meta info corresponding to the clicked item
            $('#mpg_' + id).toggle();
        });


    });

    jQuery(document).ready(function($) {
        $('.fetch_data').click(function() {

            var pageID = $(this).attr('data-id');
            var typattrb = $(this).attr('typattrb');

            var pagdescrition = $("#psdes_" + pageID).val();


            var titlechk = "no";
            var deschk = "no";


            /*var metaTitleRadioButton = $('input[name="metapretitle_' + pageID + '"]:checked');

            if (metaTitleRadioButton.length > 0) {
                titlechk = "yes";
            }

            var metaDescriptionRadioButton = $('input[name="metapredescription_' + pageID + '"]:checked');
            if (metaDescriptionRadioButton.length > 0) {
                deschk = "yes";
            }*/

            if (typattrb == "meta_titlegt") {
                titlechk = "yes";
            }

            if (typattrb == "meta_descgt") {
                deschk = "yes";
            }

            if (typattrb == "meta_both") {
                titlechk = "yes";
                deschk = "yes";
            }


            /*if (titlechk == "no" && deschk == "no") {

                titlechk = "yes";
                deschk = "yes";
                
            }*/
            var chkregen = $("#regen_" + pageID).val();

            var foukeyword = $('textarea[name="meta_focus_' + pageID + '"]').val();

            //else {
            jQuery('#custom-loader_cust').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'fetchmeta_rec',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    foukeyword: foukeyword,
                    titlechk: titlechk,
                    deschk: deschk,
                    //post_des: pagdescrition,
                },
                success: function(response) {
                    jQuery('#custom-loader_cust').removeClass('show');
                    var resdata = JSON.parse(response);
                   
                    if (resdata.msg == "disconnect") {
                        showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                    } else if (resdata.msg == "request_limit") {
                        alert('Request limit reached');
                    } else if (resdata.msg == "invalid") {
                        alert('Invalid user');
                    } else {
                        $("#regen_" + pageID).val(1);
                        if (titlechk == 'yes') {

                            if (chkregen != "") {
                                var selectedCheckboxes = $('.pre_title_checkbox:checked');
                                if (selectedCheckboxes.length > 0) {
                                    $('.pre_title_checkbox:checked').each(function() {
                                        var getvalue = $(this).attr('reqatt');
                                        console.log(getvalue);

                                        var mettlename = $(this).attr('name');
                                        var splitcrtd = mettlename.split("_");
                                        if (resdata.data == "not_found") {
                                            $('textarea[name="meta_title_' + splitcrtd[3] + '_' + pageID + '"]').val('not_found');
                                        } else {
                                            $('textarea[name="meta_title_' + splitcrtd[3] + '_' + pageID + '"]').val(resdata.data.text.meta_title[getvalue]);
                                        }

                                    });
                                } else {
                                    if (resdata.data == "not_found") {
                                        var getval1 = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                        getval1.value = "not_found";

                                        var getval2 = document.querySelector('textarea[name="meta_title_3_' + pageID + '"]');
                                        getval2.value = "not_found";


                                        var getval3 = document.querySelector('textarea[name="meta_title_4_' + pageID + '"]');
                                        getval3.value = "not_found";
                                    } else {
                                        var getval1 = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                        getval1.value = resdata.data.text.meta_title[0];

                                        var getval2 = document.querySelector('textarea[name="meta_title_3_' + pageID + '"]');
                                        getval2.value = resdata.data.text.meta_title[1];


                                        var getval3 = document.querySelector('textarea[name="meta_title_4_' + pageID + '"]');
                                        getval3.value = resdata.data.text.meta_title[2];
                                    }

                                }

                            } else {

                                if (resdata.data == "not_found") {
                                    var getval1 = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                    getval1.value = "not_found";

                                    var getval2 = document.querySelector('textarea[name="meta_title_3_' + pageID + '"]');
                                    getval2.value = "not_found";


                                    var getval3 = document.querySelector('textarea[name="meta_title_4_' + pageID + '"]');
                                    getval3.value = "not_found";
                                } else {
                                    var getval1 = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                    getval1.value = resdata.data.text.meta_title[0];

                                    var getval2 = document.querySelector('textarea[name="meta_title_3_' + pageID + '"]');
                                    getval2.value = resdata.data.text.meta_title[1];


                                    var getval3 = document.querySelector('textarea[name="meta_title_4_' + pageID + '"]');
                                    getval3.value = resdata.data.text.meta_title[2];
                                }
                            }
                        }
                        if (deschk == 'yes') {

                            if (chkregen != "") {
                                var deschked = $('.pre_des_chk:checked');
                                if (deschked.length > 0) {
                                    $('.pre_des_chk:checked').each(function() {

                                        var getvalue = $(this).attr('desreqatt');

                                        var mettlename = $(this).attr('name');
                                        var splitcrtd = mettlename.split("_");

                                        if (resdata.data == "not_found") {
                                            $('textarea[name="meta_des_' + splitcrtd[2] + '_' + pageID + '"]').val('not_found');
                                        } else {
                                            $('textarea[name="meta_des_' + splitcrtd[2] + '_' + pageID + '"]').val(resdata.data.text.meta_description[getvalue]);
                                        }

                                    });
                                } else {
                                    if (resdata.data == "not_found") {

                                        var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                        metdesval1.value = "not_found";

                                        var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                        metdesval2.value = "not_found";

                                        var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                        metdesval3.value = "not_found";

                                    } else {

                                        var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                        metdesval1.value = resdata.data.text.meta_description[0];

                                        var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                        metdesval2.value = resdata.data.text.meta_description[1];

                                        var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                        metdesval3.value = resdata.data.text.meta_description[2];
                                    }
                                }


                            } else {

                                if (resdata.data == "not_found") {

                                    var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                    metdesval1.value = "not_found";

                                    var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                    metdesval2.value = "not_found";

                                    var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                    metdesval3.value = "not_found";

                                } else {

                                    var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                    metdesval1.value = resdata.data.text.meta_description[0];

                                    var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                    metdesval2.value = resdata.data.text.meta_description[1];

                                    var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                    metdesval3.value = resdata.data.text.meta_description[2];
                                }
                            }
                        }
                        get_request_limit();
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
            //}
        });


        $('.get_alt_tag').click(function() {
            var pageID = $(this).attr('data-id');
            // Show WordPress admin default spinner
            jQuery('#custom-loader').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'getalt_img',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                },
                success: function(response) {
                    jQuery('#custom-loader').removeClass('show');
                    var imgtagdta = JSON.parse(response);
                    $("#main_imgid_" + pageID).css('display', 'inline-block');
                    $("#imgid_" + pageID).html(imgtagdta.data);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                },
                complete: function() {
                    // Hide WordPress admin default spinner
                    jQuery('#custom-loader').removeClass('show');
                }
            });
        });


        $('.update-btn').click(function() {
            var pageID = $(this).data('page-id');

            // Get the value of the selected radio button for meta title
            // var metaTitleRadioButton = $('input[name="meta_t_radio_' + pageID + '"]:checked');
            // var mettlval = metaTitleRadioButton.val();


            // var metaDescriptionRadioButton = $('input[name="meta_d_radio_' + pageID + '"]:checked');
            // var medeslval = metaDescriptionRadioButton.val();

            // var metaDescription = $('textarea[name="meta_description_' + medeslval + '_' + pageID + '"]').val();

            var titlechk = "no";
            var deschk = "no";

            // if (metaTitleRadioButton.length > 0) {
            //     titlechk = "yes";
            // }


            // if (metaDescriptionRadioButton.length > 0) {
            //     deschk = "yes";
            // }

            var getseletddom = $('.pre_title_checkbox:checked');
            if (getseletddom.length > 1) {
                alert('Please select single meta title and description to update on your web page');
                return false;
            }

            if (getseletddom.length == 1) {
                titlechk = "yes";
            }

            var getdesc = $('.pre_des_chk:checked');
            if (getdesc.length > 1) {
                alert('Please select single meta title and description to update on your web page');
                return false;
            }

            var metaTitle = "";
            if (titlechk == "yes") {
                var mettlename = getseletddom.attr('name');

                var splitcrtd = mettlename.split("_");

                metaTitle = $('textarea[name="meta_title_' + splitcrtd[3] + '_' + pageID + '"]').val();
            }

            if (getdesc.length == 1) {
                deschk = "yes";
            }
            var metaDescriptiontxt = "";
            if (deschk == "yes") {
                var metades = getdesc.attr('name');
                var splitcrtd2 = metades.split("_");
                console.log(splitcrtd2)
                metaDescriptiontxt = $('textarea[name="meta_des_' + splitcrtd2[2] + '_' + pageID + '"]').val();
            }




            // console.log(metaTitle);
            // console.log(metaDescription);
            // return false;

            jQuery('#custom-loader_cust').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'update_meta_action',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    metaTitle: metaTitle,
                    metaDescription: metaDescriptiontxt
                },
                success: function(response) {

                    jQuery('#custom-loader_cust').removeClass('show');
                    // Update meta info display
                    showSuccessPopup('Updated Successfully');

                    if (titlechk == 'yes') {
                        var getval = document.querySelector('textarea[name="meta_title_1_' + pageID + '"]');
                        getval.value = metaTitle;
                    }
                    if (deschk == 'yes') {
                        var descsdr = document.querySelector('textarea[name="meta_des_1_' + pageID + '"]');
                        descsdr.value = metaDescriptiontxt;

                    }

                    $('#mpg_' + pageID + ' .meta-title').text(metaTitle);
                    $('#mpg_' + pageID + ' .meta-description').text(metaDescriptiontxt);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        // Add a click event handler for the submit button of each form
        $(document).on('click', '.alt_sub', function(e) {
            e.preventDefault(); // Prevent default form submission
            //alert('sss');
            var form = $(this).closest('form');
            jQuery('#custom-loader').addClass('show');
            // Serialize the form data
            var formData = form.serialize();

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'update_image_alt_text',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    fromdata: formData,
                }, // Form data
                success: function(response) {
                    jQuery('#custom-loader').removeClass('show');
                    showSuccessPopup('Updated Successfully');
                    //alert('Alt tags updated successfully!');
                    // Optionally, you can handle success response
                },
                error: function(xhr, status, error) {
                    alert('Error occurred while updating alt tags.');
                    // Optionally, you can handle error response
                }
            });
        });

        $('.bulk_gen').click(function() {

            var check_title = "no";
            var check_des = "no";
            if ($(".meta_titl_desc").prop("checked")) {
                check_title = "yes";
            }

            if ($(".meta_desc").prop("checked")) {
                check_des = "yes";
            }

            var title_selctbox = [];
            var descr_selctbox = [];

            // Iterate over each checkbox with class "title_checkbox"
            $('.title_checkbox').each(function() {
                // Check if the checkbox is checked
                if ($(this).prop('checked')) {
                    // If checked, push its name to the selectedCheckboxes array
                    title_selctbox.push($(this).attr('name'));
                }
            });

            // if (check_des == "yes") {
            $('.meta_des_box').each(function() {
                // Check if the checkbox is checked
                if ($(this).prop('checked')) {
                    // If checked, push its name to the selectedCheckboxes array
                    descr_selctbox.push($(this).attr('name'));
                }
            });
            // }
            var titelnt = title_selctbox.length;
            var desclen = descr_selctbox.length;
            var sumtoken = titelnt + desclen;
            alert('You are consuming ' + sumtoken + ' tokens');
            jQuery('#custom-loader_cust').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'bulk_meta_genrate',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    p_meta_t: title_selctbox,
                    p_meta_d: descr_selctbox,
                    gettype_title: check_title,
                    gettype_desc: check_des
                    //post_des: pagdescrition,
                },
                success: function(response) {
                    jQuery('#custom-loader_cust').removeClass('show');
                    var resdata = JSON.parse(response);

                    if (resdata.msg == "disconnect") {
                        showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                    } else if (resdata.msg == "request_limit") {
                        showSuccessPopup('Request limit reached');
                    } else if (resdata.msg == "insuffconnect") {
                        showSuccessPopup('You have insufficient connect for request');
                    } else {
                        if (check_title == 'yes' && check_des == 'no') {
                            for (var key_title in resdata) {
                                var pstid = key_title;
                                var title_text = resdata[key_title].gen_ai;
                                var getval = document.querySelector('textarea[name="meta_title_2_' + pstid + '"]');
                                getval.value = title_text;

                            }

                        } else if (check_des == 'yes' && check_title == 'no') {
                            for (var key_des in resdata) {
                                var pstid = key_des;
                                var dwesxtext = resdata[key_des].gen_ai;
                                console.log(pstid);
                                var getvaldes = document.querySelector('textarea[name="meta_description_2_' + pstid + '"]');
                                if (getvaldes) {
                                    getvaldes.value = dwesxtext || "";
                                }

                            }

                        } else if (check_des == 'yes' && check_title == 'yes') {
                            for (const key in resdata) {
                                const pstid = key;
                                const pos_titl = resdata[key].gen_ai_title;
                                const pos_titdesc = resdata[key].gen_ai_description;
                                var getval_title = document.querySelector('textarea[name="meta_title_2_' + pstid + '"]');
                                var getval_desc = document.querySelector('textarea[name="meta_description_2_' + pstid + '"]');
                                getval_title.value = pos_titl;
                                if (getval_desc) {
                                    getval_desc.value = pos_titdesc || "";
                                }

                            }

                        }
                        get_request_limit();
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });

        });

        $('.bulk_update').click(function() {

            var check_title = "no";
            var check_des = "no";
            if ($(".meta_titl_desc").prop("checked")) {
                check_title = "yes";
            }

            if ($(".meta_desc").prop("checked")) {
                check_des = "yes";
            }

            var title_selctbox = [];
            var descr_selctbox = [];

            // Iterate over each checkbox with class "title_checkbox"
            $('.postp_title').each(function() {
                var tlname = $(this).attr('name');
                var prtids = tlname.split('_');
                var pstids = prtids[3];
                title_selctbox.push({
                    [pstids]: $(this).val()
                });


            });


            $('.postp_des').each(function() {
                // Check if the checkbox is checked
                // If checked, push its name to the selectedCheckboxes array
                var desname = $(this).attr('name');
                var desprtids = desname.split('_');
                var dspstids = desprtids[3];

                descr_selctbox.push({
                    [dspstids]: $(this).val()
                });

            });


            jQuery('#custom-loader_cust').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'bulk_update_meta',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    p_meta_t: title_selctbox,
                    p_meta_d: descr_selctbox,
                    gettype_title: check_title,
                    gettype_desc: check_des
                },
                success: function(response) {
                    jQuery('#custom-loader_cust').removeClass('show');
                    if (check_title == 'yes') {
                        $('.postp_title').each(function() {
                            var tlname = $(this).attr('name');
                            var prtids = tlname.split('_');
                            var pstids = prtids[3];

                            var getval = document.querySelector('textarea[name="meta_title_1_' + pstids + '"]');
                            getval.value = $(this).val();

                        });
                    }
                    if (check_des == 'yes') {
                        $('.postp_des').each(function() {
                            var tlname = $(this).attr('name');
                            var prtids = tlname.split('_');
                            var pstids = prtids[3];
                            var getval = document.querySelector('textarea[name="meta_des_1_' + pstids + '"]');
                            getval.value = $(this).val();

                        });
                    }


                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });

        });

    });

    function call_filter() {
        var selectElement = document.getElementById("page_filter");
        var selectedValue = selectElement.value;

        if (selectedValue != "") {
            // Adding parameter to the URL
            var paramName = "aifilterpage";
            var paramValue = selectedValue;
            addParameterToURL(paramName, paramValue);
        }
    }

    // Function to add a parameter to the URL
    function addParameterToURL(paramName, paramValue) {
        var url = window.location.href;

        // Check if the URL already contains parameters
        if (url.indexOf('?') !== -1) {
            // URL already contains parameters
            url += '&' + paramName + '=' + paramValue;
        } else {
            // URL does not contain parameters
            url += '?' + paramName + '=' + paramValue;
        }

        // Redirect to the updated URL
        window.location.href = url;
    }

    function get_request_limit() {

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'fetch_req_limit',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
            },
            success: function(response) {
                var resdata = JSON.parse(response);
                if (resdata.msg == "disconnect") {
                    jQuery(".fetch_data").remove();
                    jQuery(".bulk_gen").remove();

                } else {
                    jQuery("#token_usgae").html("Token Usage: <strong>" + resdata.request_limit + "/" + resdata.total_limit + "</strong");
                }

            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });

    }
    get_request_limit();
</script>

<script>
    var acc = document.getElementsByClassName("accordionBtn");

    for (var i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            // Close all panels
            var panels = document.getElementsByClassName("panel");
            for (var j = 0; j < panels.length; j++) {
                panels[j].style.display = "none";
            }

            // Toggle active class and show panel
            this.classList.toggle("active");
            var panel = this.nextElementSibling;
            if (panel.style.display === "block") {
                panel.style.display = "none";
            } else {
                panel.style.display = "block";
            }
        });
    }
</script>