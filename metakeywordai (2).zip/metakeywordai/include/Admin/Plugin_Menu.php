<?php

namespace metakeywordai\Admin;

class Plugin_Menu
{
    private $lickey = "";
    private $plugiusingkey = "";
    public function __construct()
    {
        // Get the license key from the options table
        $this->lickey = get_option('license_key_ai');
        $this->plugiusingkey = get_option('cg_act_plugnname');

        // Add plugin menu to the admin dashboard
        add_action('admin_menu', array($this, 'add_plugin_menu'));

        // Enqueue scripts for the plugin
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        // Register AJAX actions for updating meta
        add_action('wp_ajax_update_meta_action', array($this, 'metupdate_cust'));
        add_action('wp_ajax_nopriv_update_meta_action', array($this, 'metupdate_cust'));

        // Register AJAX actions for updating image alt text
        add_action('wp_ajax_update_image_alt_text', array($this, 'update_image_alt_text'));
        add_action('wp_ajax_nopriv_update_image_alt_text', array($this, 'update_image_alt_text'));

        // Register AJAX actions for fetching meta data
        add_action('wp_ajax_fetchmeta_rec', array($this, 'fetchmeta_rec'));
        add_action('wp_ajax_nopriv_fetchmeta_rec', array($this, 'fetchmeta_rec'));

        // Register AJAX actions for fetching alt text data
        add_action('wp_ajax_fetchalt_rec', array($this, 'fetchalt_rec'));
        add_action('wp_ajax_nopriv_fetchalt_rec', array($this, 'fetchalt_rec'));

        // Register AJAX actions for fetching post image alt tag with image
        add_action('wp_ajax_getalt_img', array($this, 'getalt_img'));
        add_action('wp_ajax_nopriv_getalt_img', array($this, 'getalt_img'));

        // Register AJAX actions for plugin portal registration
        add_action('wp_ajax_plug_reg_portal', array($this, 'plug_reg_portal'));
        add_action('wp_ajax_nopriv_plug_reg_portal', array($this, 'plug_reg_portal'));

        // Register AJAX actions for license key validation
        add_action('wp_ajax_validate_license_key', array($this, 'validate_license_key'));
        add_action('wp_ajax_nopriv_validate_license_key', array($this, 'validate_license_key'));

        // Register AJAX actions for tracking profile data
        add_action('wp_ajax_track_profile_data', array($this, 'track_profile_data'));
        add_action('wp_ajax_nopriv_track_profile_data', array($this, 'track_profile_data'));



        // Register AJAX actions for bulk meta generation
        add_action('wp_ajax_bulk_meta_genrate', array($this, 'bulk_meta_genrate'));
        add_action('wp_ajax_nopriv_bulk_meta_genrate', array($this, 'bulk_meta_genrate'));

        // Register AJAX actions for bulk meta update
        add_action('wp_ajax_bulk_update_meta', array($this, 'bulk_update_meta'));
        add_action('wp_ajax_nopriv_bulk_update_meta', array($this, 'bulk_update_meta'));

        // Register AJAX actions for bulk alt tag AI generation
        add_action('wp_ajax_bulk_meta_alt_genrate', array($this, 'bulk_meta_alt_genrate'));
        add_action('wp_ajax_nopriv_bulk_meta_alt_genrate', array($this, 'bulk_meta_alt_genrate'));

        // Register AJAX actions for bulk alt tag update
        add_action('wp_ajax_bulk_alt_update_meta', array($this, 'bulk_alt_update_meta'));
        add_action('wp_ajax_nopriv_bulk_alt_update_meta', array($this, 'bulk_alt_update_meta'));

        // Register AJAX actions for fetching request limit
        add_action('wp_ajax_fetch_req_limit', array($this, 'fetch_req_limit'));
        add_action('wp_ajax_nopriv_fetch_req_limit', array($this, 'fetch_req_limit'));

        add_action('wp_ajax_track_plugin_data', array($this, 'track_plugin_data'));
        add_action('wp_ajax_nopriv_track_plugin_data', array($this, 'track_plugin_data'));


        // Add custom loader HTML to the admin footer
        add_action('admin_footer', array($this, 'add_custom_loader_html'));
    }



    function add_custom_loader_html()
    {
        //loader for ajax call
        echo '<div id="custom-loader_cust"><div class="loader-spinner"></div><div class="loader-text">Loading...</div></div>';
        echo '<div id="custom-loader"><div class="loader-spinner"></div><div class="loader-text">Loading...</div></div>';
    }

    /**
     * Enqueue scripts and styles for the plugin's admin pages.
     *
     * This function enqueues necessary stylesheets and JavaScript files for the plugin's admin pages.
     * It also localizes scripts with nonce and AJAX URL data for secure AJAX requests.
     *
     * @param string $hook The current admin page.
     */
    public function enqueue_scripts($hook)
    {
        // Check if the current admin page matches our plugin's pages
        if ($hook == 'cg_meta_al' || $hook == 'cg_meta_al_list') {
            // Enqueue the main plugin stylesheet
            wp_enqueue_style('cg-meta-ai-style', plugins_url('css/cg_ai.css', __FILE__));

            // Enqueue Bootstrap CSS
            wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');

            // Enqueue Bootstrap JS with jQuery as a dependency
            wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), null, true);

            // Enqueue custom JS with jQuery as a dependency
            wp_enqueue_script('custom-js', plugins_url('js/custom.js', __FILE__), array('jquery'), null, true);

            // Localize the script with new data
            wp_localize_script('custom-js', 'ajax_object', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'update_meta_nonce' => wp_create_nonce('update_meta_nonce')
            ));

            // Enqueue additional custom stylesheet  
            wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));

            // Enqueue custom script 2 with jQuery as a dependency
            wp_enqueue_script('custom-js-2', plugins_url('js/custom2.js', __FILE__), array('jquery'), null, true);

            // Localize custom script 2 with new data
            wp_localize_script('custom-js-2', 'ajax_object_2', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'update_meta_nonce' => wp_create_nonce('update_meta_nonce_2')
            ));

            // Enqueue custom script 3 with jQuery as a dependency
            wp_enqueue_script('custom-js-3', plugins_url('js/custom3.js', __FILE__), array('jquery'), null, true);

            // Localize custom script 3 with new data
            wp_localize_script('custom-js-3', 'ajax_object_3', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'update_meta_nonce' => wp_create_nonce('update_meta_nonce_3')
            ));
        }
    }



    /**
     * Adds menu pages for the MetaKeyword AI plugin.
     *
     * This function registers various menu pages for the MetaKeyword AI plugin within the WordPress admin dashboard.
     * It adds a main menu page and several submenu pages for different functionalities of the plugin.
     *
     * @since 1.0.0
     */
    public function add_plugin_menu()
    {
        // Add main menu page
        add_menu_page(
            'MetaKeyword AI',          // Page title
            'MetaKeyword AI',          // Menu title
            'manage_options',          // Capability required to access the menu
            'cg_meta_al',              // Menu slug
            array($this, 'plugin_page'), // Callback function to display page content
            'dashicons-list-view',     // Icon URL or name
            80                         // Position in the menu
        );

        // Add submenu page for the list page
        add_submenu_page(
            'cg_meta_al',              // Parent menu slug
            'List Page',               // Page title
            'List Page',               // Menu title
            'manage_options',          // Capability required to access the menu
            'cg_meta_al_list',         // Menu slug
            array($this, 'render_list_content') // Callback function to display page content
        );

        // Add submenu page for the license key
        add_submenu_page(
            'cg_meta_al',              // Parent menu slug
            'License Key',             // Page title
            'License Key',             // Menu title
            'manage_options',          // Capability required to access the menu
            'cg_meta_license_key',     // Menu slug
            array($this, 'render_license_key') // Callback function to display page content
        );

        // Add submenu page for the profile
        add_submenu_page(
            'cg_meta_al',              // Parent menu slug
            'Profile',                 // Page title
            'Profile',                 // Menu title
            'manage_options',          // Capability required to access the menu
            'cg_meta_profile',         // Menu slug
            array($this, 'render_profile') // Callback function to display page content
        );

        // Add submenu page for the profile
        add_submenu_page(
            'cg_meta_al',              // Parent menu slug
            'Setting',                 // Page title
            'Setting',                 // Menu title
            'manage_options',          // Capability required to access the menu
            'cg_meta_setting',         // Menu slug
            array($this, 'render_setting') // Callback function to display page content
        );

        // Conditionally add hidden submenu page for the product view
        if (!defined('DO_NOT_SHOW_SUBMENU')) {
            add_submenu_page(
                null,                  // Parent menu slug (null to hide it from the menu)
                'View Page',           // Page title
                'View Page',           // Menu title
                'manage_options',      // Capability required to access the menu
                'cg_meta_al_product',  // Menu slug
                array($this, 'render_list_view') // Callback function to display page content
            );
        }

        // Add hidden submenu page for the alt tag view
        add_submenu_page(
            null,                  // Parent menu slug (null to hide it from the menu)
            'View Page',           // Page title
            'View Page',           // Menu title
            'manage_options',      // Capability required to access the menu
            'cg_meta_al_altag',    // Menu slug
            array($this, 'render_alttag_view') // Callback function to display page content
        );

        add_submenu_page(
            null,                  // Parent menu slug (null to hide it from the menu)
            'View Page',           // Page title
            'View Page',           // Menu title
            'manage_options',      // Capability required to access the menu
            'cg_meta_al_ogtag',    // Menu slug
            array($this, 'render_ogtag_view') // Callback function to display page content
        );

        // Optionally remove the menu page from the menu
        // add_action('admin_head', array($this, 'remove_custom_page_menu'));
    }



    /**
     * Callback function to display the main plugin page.
     *
     * This function is responsible for rendering the main plugin page within the WordPress admin dashboard.
     * It enqueues the custom stylesheet for styling purposes and includes necessary files such as header and the 'get started' page content.
     *
     * @since 1.0.0
     */
    public function plugin_page()
    {
        // Enqueue the custom stylesheet for the plugin page
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));

        // Include the header file
        include(__DIR__ . '/header.php');

        // Include the get started page file
        include(__DIR__ . '/getstarted_page.php');
    }



    /**
     * Callback function to render the license key page.
     *
     * This function is responsible for rendering the license key page within the WordPress admin dashboard.
     * It enqueues the custom stylesheet for styling purposes and includes necessary files such as header and the plugin activation content.
     *
     * @since 1.0.0
     */
    public function render_license_key()
    {
        // Enqueue the custom stylesheet for the license key page
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));

        // Include the header file
        include(__DIR__ . '/header.php');

        // Include the plugin activation file
        include(__DIR__ . '/plugin_activate.php');
    }


    /**
     * Callback function to render the profile page.
     *
     * This function is responsible for rendering the profile page within the WordPress admin dashboard.
     * It enqueues the custom stylesheet for styling purposes, retrieves necessary data from external API using cURL, and includes necessary files such as header and the profile page content.
     *
     * @since 1.0.0
     */
    public function render_profile()
    {
        // Enqueue the custom stylesheet for the profile page
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));

        // Get the admin email from the WordPress options
        $admin_email = get_option('admin_email');

        // Get the site URL
        $site_url = get_site_url();

        // Normalize the site URL by removing 'https://' and 'www.'
        $nsite_url = str_replace(array("https://", "www."), "", $site_url);

        // Prepare data to send in the request
        $request_data = array(
            'license_key' => $this->lickey,
            'admin_email' => $admin_email,
            'site_url' => trim($nsite_url),
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/getinfo');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        $response = curl_exec($ch);

        // Decode the JSON response
        $getres = json_decode($response);

        // Close cURL session
        curl_close($ch);

        // Get the data from the response
        $alldata = $getres->data;

        // Include the header file
        include(__DIR__ . '/header.php');

        // Include the profile page file
        include(__DIR__ . '/profile_page.php');
    }




    /**
     * Callback function to render the list content page.
     *
     * This function is responsible for rendering the list content page within the WordPress admin dashboard.
     * It checks if the license key is empty and redirects to the license key page if necessary.
     * It enqueues necessary scripts and styles, including pagination parameters, and includes necessary files such as header and the list content UI.
     *
     * @since 1.0.0
     */
    public function render_list_content()
    {
        if ($this->lickey == "") {
            // Redirect to license key page if the license key is empty
            echo "<script>window.location='admin.php?page=cg_meta_license_key'</script>";
            exit; // Always exit after a redirect to prevent further execution
        }

        // Enqueue necessary scripts and styles
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_style('jquery-ui-style', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        wp_enqueue_style('cg-ai-style', plugins_url('css/cg_ai.css', __FILE__));
        wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), null, true);
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));
        wp_enqueue_script('metakeywordai-logo', plugins_url('images/logo.png', __FILE__), array(), null, false);

        // Define pagination parameters
        $pagination_args = array(
            'total' => ceil(count(get_pages()) / 10), // Total number of pages divided by number of pages per page
            'current' => max(1, get_query_var('paged')),
            'show_all' => false,
            'end_size' => 1,
            'mid_size' => 2,
            'prev_next' => true,
            'prev_text' => __('« Previous'),
            'next_text' => __('Next »'),
        );
        $plgactive = $this->plugiusingkey;
        // Include the header and the list content UI
        include(__DIR__ . '/header.php');
        include(__DIR__ . '/pages_list_ui.php');
    }


    /**
     * Callback function to render the list view page.
     *
     * This function is responsible for rendering the list view page within the WordPress admin dashboard.
     * It checks if the license key is empty and redirects to the license key page if necessary.
     * It enqueues necessary scripts and styles, and includes necessary files such as header and the list view content UI.
     * If WooCommerce is active, it retrieves and displays a list of products.
     *
     * @since 1.0.0
     */
    public function render_list_view()
    {
        if ($this->lickey == "") {
            // Redirect to license key page if the license key is empty
            echo "<script>window.location='admin.php?page=cg_meta_license_key'</script>";
            exit; // Always exit after a redirect to prevent further execution
        }

        // Enqueue necessary scripts and styles
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_style('jquery-ui-style', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        wp_enqueue_style('cg-ai-style', plugins_url('css/cg_ai.css', __FILE__));
        wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), null, true);
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));
        wp_enqueue_script('metakeywordai-logo', plugins_url('images/logo.png', __FILE__), array(), null, false);

        // Retrieve products if WooCommerce is active
        if (is_plugin_active('woocommerce/woocommerce.php')) {
            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number
            $products = wc_get_products(array(
                'status' => 'publish', // Retrieve only published products
                'limit' => 5,          // Number of products per page
                'offset' => ($paged - 1) * 5, // Offset calculation
            ));
        }

        // Include the header and the product list UI
        include(__DIR__ . '/header.php');
        include(__DIR__ . '/product_list_ui.php');
    }


    /**
     * Callback function to render the alt tag view page.
     *
     * This function is responsible for rendering the alt tag view page within the WordPress admin dashboard.
     * It checks if the license key is empty and redirects to the license key page if necessary.
     * It enqueues necessary scripts and styles, and includes necessary files such as header and the alt tag images UI.
     * If WooCommerce is active, it retrieves and displays a list of products.
     *
     * @since 1.0.0
     */
    public function render_alttag_view()
    {
        if ($this->lickey == "") {
            // Redirect to license key page if the license key is empty
            echo "<script>window.location='admin.php?page=cg_meta_license_key'</script>";
            exit; // Always exit after a redirect to prevent further execution
        }

        // Enqueue necessary scripts and styles
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_style('jquery-ui-style', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        wp_enqueue_style('cg-ai-style', plugins_url('css/cg_ai.css', __FILE__));
        wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), null, true);
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));
        wp_enqueue_script('metakeywordai-logo', plugins_url('images/logo.png', __FILE__), array(), null, false);

        // Retrieve products if WooCommerce is active
        if (is_plugin_active('woocommerce/woocommerce.php')) {
            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number
            $products = wc_get_products(array(
                'status' => 'publish', // Retrieve only published products
                'limit' => 5,          // Number of products per page
                'offset' => ($paged - 1) * 5, // Offset calculation
            ));
        }

        // Include the header and the alt tag images UI
        include(__DIR__ . '/header.php');
        include(__DIR__ . '/alt_tag_images.php');
    }


    /**
     * Callback function to render the Og tag view page.
     *
     * This function is responsible for rendering the Og tag view page within the WordPress admin dashboard.
     * It checks if the license key is empty and redirects to the license key page if necessary.
     * It enqueues necessary scripts and styles, and includes necessary files such as header and the alt tag images UI.
     * If WooCommerce is active, it retrieves and displays a list of products.
     *
     * @since 1.0.0
     */
    public function render_ogtag_view()
    {
        if ($this->lickey == "") {
            // Redirect to license key page if the license key is empty
            echo "<script>window.location='admin.php?page=cg_meta_license_key'</script>";
            exit; // Always exit after a redirect to prevent further execution
        }

        // Enqueue necessary scripts and styles
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_style('jquery-ui-style', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        wp_enqueue_style('cg-ai-style', plugins_url('css/cg_ai.css', __FILE__));
        wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
        wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery'), null, true);
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));
        wp_enqueue_script('metakeywordai-logo', plugins_url('images/logo.png', __FILE__), array(), null, false);

        // Retrieve products if WooCommerce is active
        if (is_plugin_active('woocommerce/woocommerce.php')) {
            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number
            $products = wc_get_products(array(
                'status' => 'publish', // Retrieve only published products
                'limit' => 5,          // Number of products per page
                'offset' => ($paged - 1) * 5, // Offset calculation
            ));
        }

        // Include the header and the alt tag images UI
        include(__DIR__ . '/header.php');
        include(__DIR__ . '/og_tag_list.php');
    }



    /**
     * Callback function to update custom meta information.
     *
     * This function is responsible for updating custom meta information for pages/posts within the WordPress admin dashboard.
     * It verifies nonce for security, checks request method and user authentication, sanitizes and validates inputs,
     * updates alt tags if provided, and updates meta information such as title and description.
     * It also updates or adds custom post meta for AIOSEO and Yoast plugins if applicable.
     *
     * @since 1.0.0
     */
    public function metupdate_cust()
    {
        // Verify nonce for security
        $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        if (!wp_verify_nonce($nonce, 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Verify request method and user authentication
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_user_logged_in()) {
            wp_send_json_error('Unauthorized access.');
        }

        // Sanitize and validate inputs
        $pageID = isset($_POST['pageID']) ? intval($_POST['pageID']) : 0;
        $metaTitle = isset($_POST['metaTitle']) ? sanitize_text_field($_POST['metaTitle']) : '';
        $metaDescription = isset($_POST['metaDescription']) ? sanitize_text_field($_POST['metaDescription']) : '';

        // Check if the page ID is valid
        if (!$pageID || !get_post($pageID)) {
            wp_send_json_error('Invalid page ID.');
        }

        // Check and update alt tags if provided
        if (isset($_POST['alt_tag'])) {
            $result = $this->update_or_add_post_meta($_POST['pageID'], '_wp_attachment_image_alt', sanitize_text_field($_POST['alt_tag']));
            if ($result !== false) {
                wp_send_json_success('Alt tags information updated successfully.');
            } else {
                wp_send_json_error('Alt tags information update failed.');
            }
        } else {
            global $wpdb;

            // Define table name
            $table_name = $wpdb->prefix . 'aioseo_posts';

            // Data to be updated
            $data = array(
                'title' => $metaTitle,
                'description' => $metaDescription
            );

            // WHERE condition
            $where = array('post_id' => $pageID);

            // Data format
            $data_format = array('%s', '%s');

            // WHERE condition format
            $where_format = array('%d');

            // Execute the update query
            $result = $wpdb->update($table_name, $data, $where, $data_format, $where_format);
            wp_reset_postdata();

            // Update or add custom post meta for AIOSEO and Yoast plugins
            if (!empty($metaTitle)) {
                //echo $metaTitle;
                $this->update_or_add_post_meta($pageID, '_aioseo_title', $metaTitle);
                $this->update_or_add_post_meta($pageID, '_yoast_wpseo_title', $metaTitle);
                $this->update_or_add_post_meta($pageID, 'rank_math_title', $metaTitle);
                $this->update_or_add_post_meta($pageID, '_og_title', $metaTitle);
                $this->update_or_add_post_meta($pageID, '_aioseo_og_title', $metaTitle);
                $this->update_or_add_post_meta($pageID, '_aioseo_twitter_title', $metaTitle);
            }
            if (!empty($metaDescription)) {
                $this->update_or_add_post_meta($pageID, 'rank_math_description', $metaDescription);
                $this->update_or_add_post_meta($pageID, '_aioseo_description', $metaDescription);
                $this->update_or_add_post_meta($pageID, '_yoast_wpseo_metadesc', $metaDescription);
                $this->update_or_add_post_meta($pageID, '_og_description', $metaDescription);
                $this->update_or_add_post_meta($pageID, '_aioseo_og_description', $metaDescription);
                $this->update_or_add_post_meta($pageID, '_aioseo_twitter_description', $metaDescription);
            }

            // Check if the update was successful
            if ($result !== false) {
                wp_send_json_success('Meta information updated successfully.');
            } else {
                wp_send_json_error('Meta information update failed.');
            }
        }
    }


    /**
     * Updates or adds post meta for a given post.
     *
     * This function checks if the post exists, then checks if the post meta exists.
     * If the post meta doesn't exist, it adds it; otherwise, it updates it.
     * If the post doesn't exist, it logs an error.
     *
     * @param int    $postID    The ID of the post.
     * @param string $metaKey   The key of the meta data.
     * @param mixed  $metaValue The value of the meta data.
     *
     * @since 1.0.0
     */
    function update_or_add_post_meta($postID, $metaKey, $metaValue)
    {
        // Check if the post exists
        if (get_post_status($postID)) {
            // If the post exists, check if the post meta exists
            if (!get_post_meta($postID, $metaKey, true)) {
                // If the post meta doesn't exist, add it
                add_post_meta($postID, $metaKey, $metaValue, true);
            } else {
                // If the post meta exists, update it
                update_post_meta($postID, $metaKey, $metaValue);
            }
        } else {
            // If the post doesn't exist, handle the error or log it
            // For example:
            error_log('Error: Attempted to update or add post meta for non-existent post ID ' . $postID);
        }
    }


    /**
     * Updates the alt tag for a given attachment.
     *
     * This function updates the alt tag for a specified attachment by updating its metadata.
     * If the attachment metadata is found, it updates the alt tag and saves the metadata.
     * If the metadata is not found, it displays an error message.
     *
     * @param int    $attachment_id The ID of the attachment.
     * @param string $new_alt_tag   The new alt tag value.
     *
     * @since 1.0.0
     */
    function update_alttags($attachment_id, $new_alt_tag)
    {
        // Get the attachment metadata
        $attachment_meta = wp_get_attachment_metadata($attachment_id);
        if ($attachment_meta) {
            // Update the alt tag in the attachment metadata
            $attachment_meta['image_meta']['alt'] = $new_alt_tag;

            // Update the attachment metadata
            wp_update_attachment_metadata($attachment_id, $attachment_meta);
            $attachment_meta = wp_get_attachment_metadata($attachment_id);

            echo 'Alt tag updated successfully.';
        } else {
            echo 'Error: Attachment metadata not found.';
        }
    }



    /**
     * Retrieves alt tags from images within the content of a specified post.
     *
     * This function searches for all image tags within the content of a specified post
     * and extracts the alt attribute values from them, returning an array of alt tags.
     *
     * @param int $post_id The ID of the post.
     *
     * @return array An array containing the alt tags of images within the post content.
     *
     * @since 1.0.0
     */
    public function get_image_alt_tags($post_id)
    {
        $image_alt_tags = array();

        // Get the post content
        $post_content = get_post_field('post_content', $post_id);

        // Find all image tags in the post content
        preg_match_all('/<img[^>]+>/', $post_content, $matches);

        // Loop through the matched image tags
        foreach ($matches[0] as $image_tag) {
            // Get the alt attribute value from the image tag
            preg_match('/alt="([^"]+)"/', $image_tag, $alt_match);

            // If alt attribute exists, add it to the array
            if (!empty($alt_match[1])) {
                $image_alt_tags[] = $alt_match[1];
            }
        }

        return $image_alt_tags;
    }


    /**
     * Fetches meta data for a given post/page ID and sends it to an external API for processing.
     *
     * This function fetches meta data including post/page description, image alt tags, and other
     * relevant information for a specified post/page ID. It then sends this data to an external API
     * endpoint for further processing.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It echoes the response from the external API and terminates the script execution.
     */
    public function fetchmeta_rec()
    {
        // Verify nonce to prevent unauthorized access
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Get the post/page ID from the request
        $post_id = isset($_POST['pageID']) ? intval($_POST['pageID']) : 0;

        // Fetch post/page description
        $post = get_post($post_id);
        $post_description = '';
        if ($post) {
            // Get the post content and strip HTML tags
            $post_description = wp_strip_all_tags($post->post_content);
        }

        // Fetch image alt tags for the post/page
        $image_alt_tags = $this->get_image_alt_tags($post_id);

        // Get the admin email address
        $admin_email = get_option('admin_email');

        // Get the site URL and remove "https://" and "www." from it
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);

        // Prepare data to send in the request
        $request_data = array(
            'post_id' => $post_id,
            'post_description' => $post_description,
            'image_alt_tags' => $image_alt_tags,
            'admin_email' => $admin_email,
            'titlechk' => $_POST['titlechk'],
            'deschk' => $_POST['deschk'],
            'foukeyword' => $_POST['foukeyword'],
            'site_url' =>  trim($nsite_url),
            'license_key' =>  $this->lickey,
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);
       

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/get-meta');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        echo $response = curl_exec($ch);
        // Close cURL session
        curl_close($ch);

        // Terminate script execution
        die();
    }


    /**
     * Fetches image alt tags for a given post/page ID and sends them to an external API for processing.
     *
     * This function fetches image alt tags associated with images attached to a specified post/page ID. 
     * It then sends this data along with other relevant information to an external API endpoint for further processing.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It echoes the response from the external API and terminates the script execution.
     */
    public function fetchalt_rec()
    {
        // Verify nonce to prevent unauthorized access
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Get the post/page ID from the request
        $post_id = isset($_POST['pageID']) ? intval($_POST['pageID']) : 0;

        // Fetch post/page description
        $post = get_post($post_id);
        $post_description = '';
        if ($post) {
            // Get the post content and strip HTML tags
            $post_description = wp_strip_all_tags($post->post_content);
        }

        // Fetch image alt tags for the post/page
        $image_alt_tags = $this->get_image_alt_tags($post_id);

        // Get the admin email address
        $admin_email = get_option('admin_email');

        // Get the site URL and remove "https://" and "www." from it
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);

        // Prepare attachment IDs array (for now only using the provided $post_id)
        $attachment_ids = array($post_id);

        // Fetch image URLs associated with the attachment IDs
        $images = array();
        foreach ($attachment_ids as $attachment_id) {
            $image_url = wp_get_attachment_url($attachment_id);
            if ($image_url) {
                $images[] = array(
                    'id' => $attachment_id,
                    'url' => $image_url
                );
            }
        }

        // Prepare data to send in the request
        $request_data = array(
            'post_id' => $post_id,
            'post_description' => $post_description,
            'image_alt_tags' => $images,
            'admin_email' => $admin_email,
            'titlechk' => 'no', // Assuming 'titlechk' is set to 'no' for this scenario
            'altchk' => 'yes', // Indicating that we are fetching alt tags
            'deschk' => 'no', // Assuming 'deschk' is set to 'no' for this scenario
            'site_url' => trim($nsite_url),
            'license_key' => $this->lickey,
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/get-meta');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        echo $response = curl_exec($ch);

        // Close cURL session
        curl_close($ch);

        // Terminate script execution
        die();
    }


    /**
     * Retrieves attachments associated with a given page or post ID.
     *
     * This function retrieves all attachments (images by default) that are associated with
     * a specified page or post ID.
     *
     * @since 1.0.0
     *
     * @param int $post_id The ID of the page or post for which attachments are to be retrieved.
     * @return array|null Array of attachment objects if found, or null if no attachments are found.
     */
    function get_attachments_by_page_or_post_id($post_id)
    {
        // Set up query arguments
        $args = array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image', // Change mime type as needed, 'image' for images
            'numberposts' => -1, // Retrieve all attachments
            'post_status' => null,
            'post_parent' => $post_id // Page or post ID
        );

        // Get attachments
        $attachments = get_posts($args);

        // Return the attachments
        return $attachments;
    }


    /**
     * Updates image alt text based on submitted form data.
     *
     * This function is triggered by an AJAX request to update the alt text of images
     * based on the submitted form data. It verifies the nonce, processes the form data,
     * and updates the alt text for selected images.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a JSON response indicating success or failure and terminates the script execution.
     */
    public function update_image_alt_text()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Decode the URL-encoded form data
        $formData = urldecode($_POST['fromdata']);

        // Parse the form data into an associative array
        parse_str($formData, $formDataArray);

        // Check if image IDs and alt texts are set
        if (!isset($formDataArray['image_id']) || !isset($formDataArray['alt_text'])) {
            wp_send_json_error('Image IDs or alt texts not provided.');
        }

        // Retrieve alt texts from form data
        $alt_text = $formDataArray['alt_text'];

        // Loop through each image ID and alt text
        foreach ($alt_text as $imgid => $alttext) {
            // Check if the corresponding checkbox is checked
            if (isset($formDataArray['img_chkbox'][$imgid]) && $formDataArray['img_chkbox'][$imgid] === 'on') {
                // Update or add alt text meta for the image
                $this->update_or_add_post_meta($imgid, '_wp_attachment_image_alt', sanitize_text_field($alttext));
            }
        }

        // Send success response
        wp_send_json_success('Alt tags updated successfully.');

        // Terminate script execution
        wp_die();
    }



    /**
     * Get attachment details by attachment IDs.
     *
     * This function retrieves the URL, title, and alt text of attachments based on provided attachment IDs.
     *
     * @param array $image_ids Array of attachment IDs.
     * @return array Array of attachment details including ID, URL, title, and alt text.
     */
    function get_attachment_details_by_ids($image_ids)
    {
        $attachment_details = array();

        // Ensure the IDs are unique and valid integers
        $image_ids = array_map('intval', array_unique($image_ids));

        foreach ($image_ids as $image_id) {
            // Get attachment details
            $attachment_url = wp_get_attachment_url($image_id);
            $attachment_title = get_the_title($image_id);
            $attachment_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);

            // Only include valid attachments
            if ($attachment_url && $attachment_title) {
                $attachment_details[] = array(
                    'id' => $image_id,
                    'url' => esc_url($attachment_url),
                    'title' => sanitize_text_field($attachment_title),
                    'alt' => sanitize_text_field($attachment_alt),
                );
            }
        }

        return $attachment_details;
    }

    /**
     * Tracks WordPress user API usage.
     *
     * This function sends a request to an external API endpoint to track WordPress user API usage.
     * It retrieves the admin user's email and the site URL, then sends this data along with the plugin's
     * license key to the external API.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a request to the external API to track user API usage.
     */
    public function track_wp_userapi()
    {
        // API URL
        $url = "https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/trackuser";

        // Get the admin user email
        $admin_email = get_option('admin_email');

        // Get the site URL
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);

        // Data to be sent in the request
        $data = array(
            'site_email' => $admin_email,
            'site_url' => trim($nsite_url),
            'license_key' =>  $this->lickey,
        );

        // Initialize cURL
        $ch = curl_init();

        // Set the URL
        curl_setopt($ch, CURLOPT_URL, $url);

        // Set the request method to POST
        curl_setopt($ch, CURLOPT_POST, 1);

        // Set the POST data
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

        // Set options to return the response as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute the request
        $response = curl_exec($ch);

        // Check for errors
        if ($response === false) {
            echo 'Curl error: ' . curl_error($ch);
        }

        // Close cURL session
        curl_close($ch);

        // Display the response
        //echo $response;
    }

    /**
     * Registers the plugin on the portal.
     *
     * This function sends a registration request to the plugin portal API to register the plugin.
     * It retrieves the registration email, admin email, and site URL, then sends this data along
     * with the plugin's license key to the portal API.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a registration request to the portal API and terminates the script execution.
     */
    public function plug_reg_portal()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Get registration email from the form data, default to empty string if not set
        $email = isset($_POST['email']) ? $_POST['email'] : '';

        // Get the admin email address
        $admin_email = get_option('admin_email');

        // Get the site URL
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);

        // Prepare data to send in the request
        $request_data = array(
            'reg_email' => $email,
            'admin_email' => $admin_email,
            'site_url' =>  trim($nsite_url),
            'license_key' =>  $this->lickey,
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/signup');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        echo $response = curl_exec($ch);

        // Close cURL session
        curl_close($ch);

        // Terminate script execution
        die();
    }


    /**
     * Validates the plugin's license key.
     *
     * This function validates the license key provided by the user by sending a request
     * to the plugin portal API. It retrieves the license key, admin email, and site URL
     * from the submitted form data, then sends this data to the portal API for validation.
     * If the validation is successful, it stores the license key in the WordPress options.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a request to the portal API to validate the license key and terminates the script execution.
     */
    public function validate_license_key()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Decode the URL-encoded form data
        $formData = urldecode($_POST['fromdata']);

        // Parse the form data into an associative array
        parse_str($formData, $formDataArray);

        // Get license key from the form data, default to empty string if not set
        $license_key = isset($formDataArray['license_key']) ? $formDataArray['license_key'] : '';

        // Get the admin email address
        $admin_email = get_option('admin_email');

        // Get the site URL
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);

        // Prepare data to send in the request
        $request_data = array(
            'license_key' => $license_key,
            'admin_email' => $admin_email,
            'site_url' => trim($nsite_url),
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/validate-license');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        echo $response = curl_exec($ch);

        // Decode the JSON response
        $getres = json_decode($response);

        // Check if validation was successful
        if (isset($getres->msg) && $getres->msg == 'success') {
            $meta_key = 'license_key_ai';

            // Update or add the license key to WordPress options
            if (!get_option($meta_key)) {
                add_option($meta_key, $license_key);
            } else {
                update_option($meta_key, $license_key);
            }
        }

        // Close cURL session
        curl_close($ch);

        // Terminate script execution
        die();
    }


    /**
     * Tracks user profile data.
     *
     * This function sends user profile data to an external API endpoint for tracking purposes.
     * It retrieves the profile data from the submitted form data, including the license key,
     * admin email, and site URL, then sends this data to the external API for tracking.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a request to the external API to track user profile data and terminates the script execution.
     */
    public function track_profile_data()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Decode the URL-encoded form data
        $formData = urldecode($_POST['fromdata']);

        // Parse the form data into an associative array
        parse_str($formData, $formDataArray);

        // Get the admin email address
        $admin_email = get_option('admin_email');

        // Get the site URL
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);

        // Prepare data to send in the request
        $request_data = array(
            'license_key' =>  $this->lickey,
            'formData' => $formDataArray,
            'site_url' =>  trim($nsite_url),
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/track-user-data');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        $response = curl_exec($ch);

        // Decode the JSON response
        $getres = json_decode($response);

        // Close cURL session
        curl_close($ch);

        // Terminate script execution
        die();
    }



    /**
     * Bulk updates meta data for posts.
     *
     * This function bulk updates meta data for posts based on the received form data.
     * It verifies the nonce, then processes the received data to update post meta titles
     * and descriptions accordingly.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a JSON response indicating success or failure and terminates the script execution.
     */
    public function bulk_update_meta()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Retrieve received post meta titles and descriptions
        $p_meta_t = $_POST['p_meta_t']; // Received array for post meta titles
        $p_meta_des = $_POST['p_meta_d']; // Received array for post meta descriptions

        // Remove numerical indices and keep only associative array structure
        $p_meta_t = array_reduce($p_meta_t, function ($result, $item) {
            $result[key($item)] = current($item);
            return $result;
        }, []);

        $p_meta_des = array_reduce($p_meta_des, function ($result, $item) {
            $result[key($item)] = current($item);
            return $result;
        }, []);

        global $wpdb;
        // Define table name
        $table_name = $wpdb->prefix . 'aioseo_posts';
        // Update post meta based on received data
        if ($_POST['gettype_title'] == 'yes' && $_POST['gettype_desc'] == 'no') {
            // Update post meta titles only
            foreach ($p_meta_t as $key => $value) {

                // Data to be updated
                $data = array(
                    'title' => $value,
                );
                // WHERE condition
                $where = array('post_id' => $key);
                // Data format
                $data_format = array('%s');
                // WHERE condition format
                $where_format = array('%d');
                // Execute the update query
                $result = $wpdb->update($table_name, $data, $where, $data_format, $where_format);
                wp_reset_postdata();

                $this->update_or_add_post_meta($key, '_aioseo_title', $value);
                $this->update_or_add_post_meta($key, '_yoast_wpseo_title', $value);
            }
        } else if ($_POST['gettype_title'] == 'no' && $_POST['gettype_desc'] == 'yes') {
            // Update post meta descriptions only
            foreach ($p_meta_des as $key => $value) {

                // Data to be updated
                $data = array(
                    'description' => $value
                );
                // WHERE condition
                $where = array('post_id' => $key);
                // Data format
                $data_format = array('%s');
                // WHERE condition format
                $where_format = array('%d');
                // Execute the update query
                $result = $wpdb->update($table_name, $data, $where, $data_format, $where_format);
                wp_reset_postdata();

                $this->update_or_add_post_meta($key, '_aioseo_description', $value);
                $this->update_or_add_post_meta($key, '_yoast_wpseo_metadesc', $value);
            }
        } else if ($_POST['gettype_title'] == 'yes' && $_POST['gettype_desc'] == 'yes') {
            // Update post meta titles and descriptions
            foreach ($p_meta_t as $key => $value) {

                // Data to be updated
                $data = array(
                    'title' => $value,
                );
                // WHERE condition
                $where = array('post_id' => $key);
                // Data format
                $data_format = array('%s');
                // WHERE condition format
                $where_format = array('%d');
                // Execute the update query
                $result = $wpdb->update($table_name, $data, $where, $data_format, $where_format);
                wp_reset_postdata();
                $this->update_or_add_post_meta($key, '_aioseo_title', $value);
                $this->update_or_add_post_meta($key, '_yoast_wpseo_title', $value);
            }
            foreach ($p_meta_des as $key => $value) {

                // Data to be updated
                $data = array(
                    'description' => $value
                );
                // WHERE condition
                $where = array('post_id' => $key);
                // Data format
                $data_format = array('%s');
                // WHERE condition format
                $where_format = array('%d');
                // Execute the update query
                $result = $wpdb->update($table_name, $data, $where, $data_format, $where_format);
                wp_reset_postdata();
                $this->update_or_add_post_meta($key, '_aioseo_description', $value);
                $this->update_or_add_post_meta($key, '_yoast_wpseo_metadesc', $value);
            }
        }

        // Send success response
        wp_send_json_success('Bulk Meta data updated successfully.');

        // Terminate script execution
        wp_die();
    }

    /**
     * Bulk updates alt tags for post images.
     *
     * This function bulk updates alt tags for post images based on the received form data.
     * It verifies the nonce, then processes the received data to update alt tags for images
     * attached to posts.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a JSON response indicating success or failure and terminates the script execution.
     */
    public function bulk_alt_update_meta()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Retrieve received post image alt tags
        $p_meta_alt = $_POST['p_meta_alt']; // Received array for post image alt tags

        // Remove numerical indices and keep only associative array structure
        $p_meta_alt = array_reduce($p_meta_alt, function ($result, $item) {
            $result[key($item)] = current($item);
            return $result;
        }, []);

        // Update alt tags for post images
        foreach ($p_meta_alt as $key => $value) {
            $this->update_or_add_post_meta($key, '_wp_attachment_image_alt', sanitize_text_field($value));
        }

        // Send success response
        wp_send_json_success('Alt tag data updated successfully.');

        // Terminate script execution
        wp_die();
    }


    /**
     * Fetches request limit data.
     *
     * This function fetches request limit data from an external API endpoint.
     * It retrieves the admin email, site URL, and license key, then sends this data
     * to the external API to fetch the request limit details.
     *
     * @since 1.0.0
     *
     * @return void This function does not return any value. It sends a request to the external API to fetch request limit data and terminates the script execution.
     */
    public function fetch_req_limit()
    {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }

        // Get the admin email address
        $admin_email = get_option('admin_email');

        // Get the site URL
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);

        // Prepare data to send in the request
        $request_data = array(
            'admin_email' => $admin_email,
            'site_url' =>  trim($nsite_url),
            'license_key' =>  $this->lickey,
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/fetch-limit');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        echo $response = curl_exec($ch);

        // Decode the JSON response
        $getres = json_decode($response);

        // Close cURL session
        curl_close($ch);

        // Terminate script execution
        die();
    }
    public function bulk_meta_genrate()
    {


        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }




        $meta_title = array();
        $meta_title_d = array();

        foreach ($_POST['p_meta_t'] as $key => $value) {
            $postget = explode('_', $value);
            $postid = $postget[3];
            $post = get_post($postid);
            $post_description = wp_strip_all_tags($post->post_content);

            $meta_title[$postid] = array("description" => $post_description);
        }

        foreach ($_POST['p_meta_d'] as $key => $value) {
            $postget = explode('_', $value);
            $postid = $postget[3];
            $post = get_post($postid);
            $post_description = wp_strip_all_tags($post->post_content);

            $meta_title_d[$postid] = array("description" => $post_description);
        }


        // Decode the URL-encoded form data
        $formData = urldecode($_POST['fromdata']);

        // Parse the form data into an associative array
        parse_str($formData, $formDataArray);



        $email = isset($_POST['email']) ? $_POST['email'] : '';


        $admin_email = get_option('admin_email');
        // Get the site URL
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);


        // Prepare data to send in the request
        $request_data = array(
            'admin_email' =>  $admin_email,
            'license_key' =>  $this->lickey,
            'titlechk' =>  $_POST['gettype_title'],
            'deschk' =>  $_POST['gettype_desc'],
            'meta_title_api' => $meta_title,
            'meta_desc_api' => $meta_title_d,
            'site_url' =>  trim($nsite_url),
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);
        //print_r($request_data);
        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/bulk-gen');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        echo $response = curl_exec($ch);
        $getres = json_decode($response);


        // Close cURL session
        curl_close($ch);
        die();
    }
    public function bulk_meta_alt_genrate()
    {


        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }




        $meta_title = array();
        $meta_title_d = array();
        $images = array();
        foreach ($_POST['p_meta_t'] as $key => $value) {
            $postget = explode('_', $value);
            $postid = $postget[3];
            $attachment_ids = array($postid); // Replace 1, 2 with actual attachment IDs



            foreach ($attachment_ids as $attachment_id) {
                $image_url = wp_get_attachment_url($attachment_id);

                if ($image_url) {
                    $images[] = array(
                        'id' => $attachment_id,
                        'url' => $image_url
                    );
                }
            }

            $data['images'] = $images;
        }


        $admin_email = get_option('admin_email');
        // Get the site URL
        $site_url = get_site_url();
        $nsite_url = str_replace("https://", " ", $site_url);
        $nsite_url = str_replace("www.", " ", $nsite_url);


        // Prepare data to send in the request
        $request_data = array(
            'image_alt_tags' => $data['images'],
            'admin_email' => $admin_email,
            'site_url' =>  trim($nsite_url),
            'license_key' =>  $this->lickey,
        );

        // Convert data to query string format
        $query_string = http_build_query($request_data);

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/bulk-alt-gen');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL request
        echo $response = curl_exec($ch);
        $getres = json_decode($response);


        // Close cURL session
        curl_close($ch);
        die();
    }

    /**
     * Callback function to render the Setting page.
     *
     * This function is responsible for rendering the setting page within the WordPress admin dashboard. where user can pick that which plugin user using
     * 
     *
     * @since 1.0.0
     */
    public function render_setting()
    {
        // Enqueue the custom stylesheet for the profile page
        wp_enqueue_style('customcss', plugins_url('css/stylesheet-meta.css', __FILE__));



        $seo_activae_plugin = $this->plugiusingkey;

        // Include the header file
        include(__DIR__ . '/header.php');

        // Include the profile page file
        include(__DIR__ . '/setting_page.php');
    }
    /**
     * Function to track and update the active plugin data.
     *
     * This function is used to track which SEO plugin user is using currenlty e.g All in on SEO, Yoast, Rank Match. user will select from drop down list.
     
     */
    public function track_plugin_data()
    {

        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'update_meta_nonce')) {
            wp_send_json_error('Invalid nonce.');
        }


        $formData = urldecode($_POST['fromdata']);

        parse_str($formData, $formDataArray);
        $ai_meta_key = 'cg_act_plugnname';
        $ai_meta_value = isset($formDataArray['using_plugin']) ? $formDataArray['using_plugin'] : '';



        // Check if the meta value is set correctly
        if (empty($ai_meta_value)) {
        } else {
            // Update or add the license key to WordPress options
            if (!get_option($ai_meta_key)) {

                add_option('cg_act_plugnname', $ai_meta_value);
            } else {

                update_option('cg_act_plugnname', $ai_meta_value);
            }

            // Output the updated value

        }
        // Send success response
        wp_send_json_success('Data updated successfully.');

        // Terminate script execution
        wp_die();
    }
}
