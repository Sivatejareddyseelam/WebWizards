<?php

function get_post_description($post_id)
{
    $post = get_post($post_id);
    if ($post) {
        // Get the post content and strip HTML tags
        $description = wp_strip_all_tags($post->post_content);
        return $description;
    }
    return false;
}

function get_all_images_by_post_id($post_id)
{
    // Get the post object
    $post = get_post($post_id);

    if (!$post) {
        return [];
    }

    $images = [];

    // Get the featured image
    $featured_image_id = get_post_thumbnail_id($post_id);
    if ($featured_image_id) {
        $featured_image_url = wp_get_attachment_url($featured_image_id);
        if ($featured_image_url) {
            $images[] = $featured_image_url;
        }
    }

    // Get images from the post content
    if ($post->post_content) {
        $content = $post->post_content;
        preg_match_all('/<img[^>]+src="([^">]+)"/i', $content, $matches);
        if (!empty($matches[1])) {
            $images = array_merge($images, $matches[1]);
        }
    }

    // If the post is a product, get the gallery images
    if ($post->post_type === 'product') {
        $product = wc_get_product($post_id);
        if ($product) {
            $gallery_image_ids = $product->get_gallery_image_ids();
            foreach ($gallery_image_ids as $image_id) {
                $gallery_image_url = wp_get_attachment_url($image_id);
                if ($gallery_image_url) {
                    $images[] = $gallery_image_url;
                }
            }
        }
    }

    return $images;
}
$aifilterpage = isset($_GET['aifilterpage']) ? $_GET['aifilterpage'] : 10; // Current page number


?>




<div class="flexButtonsCg">
    <div class="gridFlexCg">
        <ul class="buttonsCg">
            <li><a id="pages-tab" href="admin.php?page=cg_meta_al_list" class="normalBtnCG normalBtnCGV2">Pages</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_product" class="normalBtnCG normalBtnCGV2">Products</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_altag" class="normalBtnCG normalBtnCGV2">Alt Tags</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_ogtag" class="normalBtnCG">Og Tags</a></li>

        </ul>
    </div>


    <div class="gridFlexCg justifyRight">
        <ul class="buttonsCg">
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_gen">Generate Bulk Information</a></li>
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_update">Update Bulk Information</a></li>
        </ul>
    </div>
</div>


<div class="tableStCg" class="tab-pane fade show active" id="pages" role="tabpanel" aria-labelledby="pages-tab">
    <div class="scrollTable">

        <div class="bgAreaGray37">
            <table cellpadding="0" cellspacing="0">
                <tbody>

                    <tr class="flexDs">

                        <td class="wd30s noBGColor noBGColor2">
                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                <tbody>
                                    <tr>
                                        <td><b>Page Title</b></td>
                                        <td><b>URLs</b></td>
                                    </tr>



                                </tbody>
                            </table>

                        </td>

                        <td class="wd70s noBGColor noBGColor2">
                            <table cellpadding="0" cellspacing="0">
                                <tbody>
                                    <tr class="rightFlexForm">
                                        <td class="wd80s">
                                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                                <tbody>
                                                    <tr class="flexWdTd">
                                                        <td></td>
                                                        <td></td>
                                                    </tr>

                                                </tbody>
                                            </table>

                                        </td>


                                        <td class="wd20s">
                                            <table cellpadding="0" cellspacing="0" class="boldTd">
                                                <tbody>
                                                    <tr>

                                                        <td><b>Action<b></td>

                                                    </tr>
                                                </tbody>
                                            </table>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>


                    </tr>
                </tbody>
            </table>
        </div>
        <div class="borderSeparate">
            <?php

            //foreach ($pages as $page) :

            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number


            $args = array(
                'post_type' => array('post', 'page', 'product'), // Include both posts and pages and products
                'post_status' => 'publish', // Only published posts/pages
                'posts_per_page' => $aifilterpage, // Limiting to 10 posts/pages per page
                'offset' => ($paged - 1) * $aifilterpage, // Offset calculation
            );
            $query = new WP_Query($args);
            while ($query->have_posts()) : $query->the_post();

                //$post_description = get_post_description($page->ID);
                // $allpostmeta = get_post_meta($post_id);
                // echo"<pre>"; print_r($allpostmeta); echo "</pre>";
                $post_id = get_the_ID();

                $getalimages = get_all_images_by_post_id($post_id);

                // echo "<pre>";
                // print_r($getalimages);
                // echo "</pre>";

                /* $yoast_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
        $rank_math_title = get_post_meta($post_id, 'rank_math_title', true);
        $aioseop_title = get_post_meta($post_id, '_aioseop_title', true);

        $yoast_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
        $aioseop_description = get_post_meta($post_id, '_aioseop_description', true);
        $rank_math_description = get_post_meta($post_id, 'rank_math_description', true);

        if (!empty($yoast_title)) {
            $seo_title = $yoast_title;
        } elseif (!empty($aioseop_title)) {
            $seo_title = $aioseop_title;
        } elseif (!empty($rank_math_title)) {
            $seo_title = $rank_math_title;
        }

        if (!empty($yoast_description)) {
            $seo_description = $yoast_description;
        } elseif (!empty($aioseop_description)) {
            $seo_description = $aioseop_description;
        } elseif (!empty($rank_math_description)) {
            $seo_description = $rank_math_description;
        }*/
                $seo_title = "";
                $seo_description = "";
                if ($plgactive == "cg_aioseo") {
                    $seo_title = get_post_meta($post_id, '_aioseop_title', true);
                    $seo_description = get_post_meta($post_id, '_aioseop_description', true);
                } else if ($plgactive == "cg_yoast") {
                    $seo_title = get_post_meta($post_id, '_yoast_wpseo_title', true);
                    $seo_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
                } else if ($plgactive == "cg_rank_math") {
                    $seo_title = get_post_meta($post_id, 'rank_math_title', true);
                    $seo_description = get_post_meta($post_id, 'rank_math_description', true);
                }

            ?>
                <div class="bgAreaGray37">


                    <table cellpadding="0" cellspacing="0">
                        <tbody>
                            <tr class="flexDs">

                                <td class="wd30s noBGColor">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="titLeLink titLeLinkWeight500"><?php the_title(); ?></div>
                                                </td>
                                                <td>
                                                    <div class="titLeLink"><a href="<?php the_permalink(); ?>"><?php the_permalink(); ?></a></div>
                                                </td>
                                            </tr>



                                        </tbody>
                                    </table>


                                </td>
                                <td class="wd70s noBGColor">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr class="rightFlexForm">
                                                <td class="wd80s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr class="flexWdTd ogTagTdWidth">
                                                                <?php
                                                                if (!empty($getalimages)) {
                                                                    foreach ($getalimages as $imgkey => $imgsrcval) { ?>
                                                                        <td>
                                                                            <div class="imageRadius87Cg"><img src="<?php echo $imgsrcval; ?>"></div>
                                                                        </td>
                                                                    <?php }
                                                                } else { ?>
                                                                    <td>
                                                                        <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                    </td>
                                                                <?php } ?>
                                                                <!--<td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>
                                                                <td>
                                                                    <div class="imageRadius87Cg"><img src="http://prospectsinfluentialnew.cgcolors.co/wp-content/uploads/2024/06/image-2.jpg"></div>
                                                                </td>-->
                                                            </tr>

                                                        </tbody>
                                                    </table>

                                                </td>


                                                <td class="wd20s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>

                                                                <td class="centerAppBtn">
                                                                </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>


                            </tr>

                            <tr>
                                <td class="leftAppBtn">
                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH clickToExpand fetch_data" data-id="<?php echo $post_id; ?>">Facebook</button></div>
                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH blueBtncg update-btn" data-page-id="<?php echo $post_id; ?>">Twitter</button></div>
                                </td>
                            </tr>
                            <tr class="flexDs">

                                <td class="wd100sOgTags">
                                    <table cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr class="rightFlexForm">
                                                <td class="wd80s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr class="flexWdTd">
                                                                <td class="centerFlexAlignCg">
                                                                    <div class="titLeLink titLeLinkWeight500 paddingCentertCG">Title</div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild PDleft22"><textarea name="meta_title_1_<?php echo $post_id; ?>" readonly><?php echo $seo_title; ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="0" name="meta_d_2_chkd_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_2_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="0" name="meta_d_2_chkd_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_2_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_des_chk" desreqatt="0" name="meta_d_2_chkd_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_des_2_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr class="flexWdTd">
                                                                <td class="centerFlexAlignCg">
                                                                    <div class="titLeLink titLeLinkWeight500 paddingCentertCG">Description</div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild PDleft22"><textarea name="meta_title_1_<?php echo $post_id; ?>" readonly><?php echo $seo_title; ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="1" name="meta_t_chk_3_<?php echo $post_id; ?>" value="3"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_3_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="1" name="meta_t_chk_3_<?php echo $post_id; ?>" value="3"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_3_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                                                        <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="pre_title_checkbox" reqatt="1" name="meta_t_chk_3_<?php echo $post_id; ?>" value="3"><span class="checkmark"></span></label></div>
                                                                        <div class="flexCheckCgChild PDleft22"><textarea class="postp_title" name="meta_title_3_<?php echo $post_id; ?>" placeholder=""></textarea></div>
                                                                    </div>
                                                                </td>
                                                            </tr>

                                                        </tbody>
                                                    </table>

                                                </td>

                                                <input type="hidden" id="regen_<?php echo $post_id; ?>" value="">
                                                <td class="wd20s">
                                                    <table cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                            <tr>

                                                                <td class="centerAppBtn">
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH clickToExpand fetch_data" data-id="<?php echo $post_id; ?>">Generate</button></div>
                                                                    <div class="generatePlain heightBtnCenter2"><button class="btnWdH blueBtncg update-btn" data-page-id="<?php echo $post_id; ?>">Update</button></div>
                                                                </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>







                            </tr>
                        </tbody>
                    </table>

                </div>


                <div class="activeExCgtable paddingAreaCg" id="main_imgid_<?php echo $post_id; ?>" style="display: none;">
                    <div class="activeExCgtableH6">
                        <h6>Alt Tags Generation</h6>
                        <div class="gridFlexCG" id="imgid_<?php echo $post_id; ?>">



                        </div>
                    </div>
                </div>

            <?php //endforeach;

            endwhile;
            // Restore original Post Data
            wp_reset_postdata();

            // Get the total number of published pages
            $total_pages = ceil(wp_count_posts('page')->publish / $aifilterpage);

            // Get the current page number
            // $paged = max(1, get_query_var('paged', 1));
            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number

            // Check if there's more than one page
            if ($total_pages > 1) {
                echo '<div class="flexDirectionCg">'; // Opening div tag

                // Generate pagination links
                echo paginate_links(array(
                    'base'      => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                    'format'    => '?paged=%#%',
                    'current'   => $paged,
                    'total'     => $total_pages,
                    'mid_size'  => 2,
                    'prev_text' => __('« Previous'),
                    'next_text' => __('Next »'),
                ));

                echo '</div>'; // Closing div tag
            }

            /*$total_pages = ceil(wp_count_posts('page')->publish / $aifilterpage); // Total number of pages
    echo '<div class="flexDirectionCg">'; // Opening div tag 
    echo paginate_links(array(
        'total' => $total_pages,
        'current' => $paged,
    ));*/
            echo '</div></div>'; // Closing div tag

            ?>
        </div>

        <!-- <div class="flexDirectionCg">
    <div class="nameCGItem prevCg2"><a href="#">Prev</a></div>
    <div class="nameCGItem"><a href=""><span class="activeCghover">1</span></a></div>
    <div class="nameCGItem"><a href=""><span>2</span></a></div>
    <div class="nameCGItem"><a href=""><span>3</span></a></div>
    <div class="nameCGItem"><a href=""><span>4</span></a></div>
    <div class="nameCGItem"><a href=""><span>5</span></a></div>
    <div class="nameCGItem prevCg2"><a href="#">Next</a></div>
</div> -->

        <!-- JavaScript to handle click event of view links -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script>
            //code for check all checkbox for meta title 
            $("body").on("click", ".meta_titl_desc", function() {

                if ($(this).prop("checked")) {
                    $(".title_checkbox").prop("checked", true);
                } else {
                    $(".title_checkbox").prop("checked", false);
                }

            });

            //code for check all checkbox for meta descritption 
            $("body").on("click", ".meta_desc", function() {

                if ($(this).prop("checked")) {
                    $(".meta_des_box").prop("checked", true);
                } else {
                    $(".meta_des_box").prop("checked", false);
                }

            });


            // Function to display success message in a popup
            function showSuccessPopup(message) {
                // Create a new element for the popup message
                var popup = document.createElement('div');
                popup.innerHTML = '<div class="updatedDataNow">' +
                    '<p>' + message + '</p>' +
                    '<button id="closeButton">Close</button>' +
                    '</div>';

                // Style the popup element
                popup.style.position = 'fixed';
                popup.style.top = '50%';
                popup.style.left = '50%';
                popup.style.transform = 'translate(-50%, -50%)';
                popup.style.backgroundColor = 'rgb(0 0 0 / 27%)';
                popup.style.border = '1px solid #cccccc';
                popup.style.padding = '20px';
                popup.style.zIndex = '10000';
                popup.style.width = '100%';
                popup.style.height = '100%';

                // Append the popup to the body
                document.body.appendChild(popup);

                // Close the popup when the close button is clicked
                var closeButton = document.getElementById('closeButton');
                closeButton.addEventListener('click', function() {
                    document.body.removeChild(popup);
                });
            }

            jQuery(document).ready(function($) {


                // Handle click event of view links
                $('.view-link').click(function(e) {
                    e.preventDefault();
                    // Hide all previously expanded meta info
                    $('.meta-info').hide();
                    // Fetch the ID and type of the clicked item
                    var id = $(this).data('id');
                    // Show the meta info corresponding to the clicked item
                    $('#mpg_' + id).toggle();
                });


            });

            jQuery(document).ready(function($) {
                $('.fetch_data').click(function() {

                    var pageID = $(this).attr('data-id');

                    var pagdescrition = $("#psdes_" + pageID).val();


                    var titlechk = "no";
                    var deschk = "no";


                    var metaTitleRadioButton = $('input[name="meta_t_radio_' + pageID + '"]:checked');

                    if (metaTitleRadioButton.length > 0) {
                        titlechk = "yes";
                    }

                    var metaDescriptionRadioButton = $('input[name="meta_d_radio_' + pageID + '"]:checked');
                    if (metaDescriptionRadioButton.length > 0) {
                        deschk = "yes";
                    }
                    if (titlechk == "no" && deschk == "no") {
                        alert('Please select meta title OR meta description');
                        //showSuccessPopup('Your success message goes here.');
                        return false;
                    } else {
                        jQuery('#custom-loader_cust').addClass('show');
                        $.ajax({
                            url: '<?php echo admin_url('admin-ajax.php'); ?>',
                            type: 'POST',
                            data: {
                                action: 'fetchmeta_rec',
                                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                                pageID: pageID,
                                titlechk: titlechk,
                                deschk: deschk,
                                //post_des: pagdescrition,
                            },
                            success: function(response) {
                                jQuery('#custom-loader_cust').removeClass('show');
                                var resdata = JSON.parse(response);
                                if (resdata.msg == "disconnect") {
                                    showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                                } else if (resdata.msg == "request_limit") {
                                    alert('Request limit reached');
                                } else if (resdata.msg == "invalid") {
                                    alert('Invalid user');
                                } else {
                                    if (titlechk == 'yes') {
                                        var getval = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                        getval.value = resdata.data.text.meta_title;
                                    }
                                    if (deschk == 'yes') {
                                        var metdesval = document.querySelector('textarea[name="meta_description_2_' + pageID + '"]');
                                        metdesval.value = resdata.data.text.meta_description;
                                    }
                                    get_request_limit();
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                            }
                        });
                    }
                });


                $('.get_alt_tag').click(function() {
                    var pageID = $(this).attr('data-id');
                    // Show WordPress admin default spinner
                    jQuery('#custom-loader').addClass('show');
                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: {
                            action: 'getalt_img',
                            nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                            pageID: pageID,
                        },
                        success: function(response) {
                            jQuery('#custom-loader').removeClass('show');
                            var imgtagdta = JSON.parse(response);
                            $("#main_imgid_" + pageID).css('display', 'inline-block');
                            $("#imgid_" + pageID).html(imgtagdta.data);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        },
                        complete: function() {
                            // Hide WordPress admin default spinner
                            jQuery('#custom-loader').removeClass('show');
                        }
                    });
                });


                $('.update-btn').click(function() {
                    var pageID = $(this).data('page-id');
                    jQuery('#custom-loader_cust').addClass('show');
                    // Get the value of the selected radio button for meta title
                    var metaTitleRadioButton = $('input[name="meta_t_radio_' + pageID + '"]:checked');
                    var mettlval = metaTitleRadioButton.val();
                    var metaTitle = $('textarea[name="meta_title_' + mettlval + '_' + pageID + '"]').val();

                    var metaDescriptionRadioButton = $('input[name="meta_d_radio_' + pageID + '"]:checked');
                    var medeslval = metaDescriptionRadioButton.val();

                    var metaDescription = $('textarea[name="meta_description_' + medeslval + '_' + pageID + '"]').val();

                    var titlechk = "no";
                    var deschk = "no";

                    if (metaTitleRadioButton.length > 0) {
                        titlechk = "yes";
                    }


                    if (metaDescriptionRadioButton.length > 0) {
                        deschk = "yes";
                    }

                    // console.log(metaTitle);
                    // console.log(metaDescription);
                    // return false;
                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: {
                            action: 'update_meta_action',
                            nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                            pageID: pageID,
                            metaTitle: metaTitle,
                            metaDescription: metaDescription
                        },
                        success: function(response) {

                            jQuery('#custom-loader_cust').removeClass('show');
                            // Update meta info display
                            showSuccessPopup('Updated Successfully');

                            if (titlechk == 'yes') {
                                var getval = document.querySelector('textarea[name="meta_title_1_' + pageID + '"]');
                                getval.value = metaTitle;
                            }
                            if (deschk == 'yes') {
                                var descsdr = document.querySelector('textarea[name="meta_des_1_' + pageID + '"]');
                                descsdr.value = metaDescription;

                            }

                            $('#mpg_' + pageID + ' .meta-title').text(metaTitle);
                            $('#mpg_' + pageID + ' .meta-description').text(metaDescription);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });
                });

                // Add a click event handler for the submit button of each form
                $(document).on('click', '.alt_sub', function(e) {
                    e.preventDefault(); // Prevent default form submission
                    //alert('sss');
                    var form = $(this).closest('form');
                    jQuery('#custom-loader').addClass('show');
                    // Serialize the form data
                    var formData = form.serialize();

                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: {
                            action: 'update_image_alt_text',
                            nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                            fromdata: formData,
                        }, // Form data
                        success: function(response) {
                            jQuery('#custom-loader').removeClass('show');
                            showSuccessPopup('Updated Successfully');
                            //alert('Alt tags updated successfully!');
                            // Optionally, you can handle success response
                        },
                        error: function(xhr, status, error) {
                            alert('Error occurred while updating alt tags.');
                            // Optionally, you can handle error response
                        }
                    });
                });

                /* $('.bulk_gen').click(function() {
                     var check_title = $(".meta_titl_desc").prop("checked") ? "yes" : "no";
                     var check_des = $(".meta_desc").prop("checked") ? "yes" : "no";

                     var title_selctbox = [];
                     var descr_selctbox = [];

                     $('.title_checkbox').each(function() {
                         if ($(this).prop('checked')) {
                             title_selctbox.push($(this).attr('name'));
                         }
                     });

                     $('.meta_des_box').each(function() {
                         if ($(this).prop('checked')) {
                             descr_selctbox.push($(this).attr('name'));
                         }
                     });
                     var titelnt = title_selctbox.length;
                     var desclen = descr_selctbox.length;
                     var sumtoken = titelnt + desclen;
                     alert('You are consuming ' + sumtoken + ' tokens');
                     jQuery('#custom-loader').addClass('show');

                     var stopExecution = false; // Flag to stop execution

                     function makeAjaxRequest(data) {
                         return new Promise((resolve, reject) => {
                             if (stopExecution) {
                                 reject('Execution stopped'); // Reject if execution is stopped
                                 return;
                             }
                             $.ajax({
                                 url: '<?php echo admin_url('admin-ajax.php'); ?>',
                                 type: 'POST',
                                 data: data,
                                 success: function(response) {
                                     resolve(response); // Resolve the promise with the response
                                 },
                                 error: function(xhr, status, error) {
                                     reject(error); // Reject the promise with the error
                                 }
                             });
                         });
                     }

                     function executePromisesSequentiallyWithDelay(promises, delay) {
                         return promises.reduce((promiseChain, currentPromise, index) => {
                             return promiseChain.then(chainResults =>
                                 new Promise((resolve, reject) => {
                                     if (stopExecution) {
                                         reject('Execution stopped'); // Reject if execution is stopped
                                         return;
                                     }
                                     setTimeout(() => {
                                         currentPromise().then(currentResult => {
                                             var percentage = Math.round(((index + 1) / promises.length) * 100);
                                             $('.progress-bar').css('width', percentage + '%');
                                             $('.percentage-text').text(percentage + '%');

                                             console.log(`Response for request ${index + 1}:`, currentResult);
                                             var resdata = JSON.parse(currentResult);
                                             if (resdata.msg == "disconnect") {
                                                 showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                                                 stopExecution = true; // Set the flag to stop execution
                                                 reject('Execution stopped due to disconnect'); // Reject to stop the chain
                                                 return;
                                             } else if (resdata.msg == "request_limit") {
                                                 alert('Request limit reached');
                                                 stopExecution = true; // Set the flag to stop execution
                                                 reject('Request limit reached'); // Reject to stop the chain
                                                 return;
                                             } else if (resdata.msg == "invalid") {
                                                 alert('Invalid user');
                                                 stopExecution = true; // Set the flag to stop execution
                                                 reject('Invalid user'); // Reject to stop the chain
                                                 return;
                                             } else {
                                                 var pageID = resdata.postid;
                                                 if (check_title == 'yes') {
                                                     if (pageID) {
                                                         var getval = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                                                         if (getval) {
                                                             if (resdata.data != "not_found") {
                                                                 getval.value = resdata.data.text.meta_title;
                                                             } else {
                                                                 getval.value = 'no records found';
                                                             }
                                                         }
                                                     }
                                                 }
                                                 if (check_des == 'yes') {
                                                     var metdesval = document.querySelector('textarea[name="meta_description_2_' + pageID + '"]');
                                                     if (metdesval) {
                                                         if (resdata.data != "not_found") {
                                                             metdesval.value = resdata.data.text.meta_description;
                                                         } else {
                                                             metdesval.value = 'no records found';
                                                         }
                                                     }
                                                 }
                                             }
                                             resolve([...chainResults, currentResult]);
                                         }).catch(error => {
                                             reject(error);
                                         });
                                     }, delay);
                                 })
                             );
                         }, Promise.resolve([]));
                     }

                     var promises = [];
                     if (check_title == 'yes' && check_des == 'no') {
                         title_selctbox.forEach(function(title) {
                             var pdisarr = title.split('_');
                             var pageID = pdisarr[3];
                             var requestData = {
                                 action: 'fetchmeta_rec',
                                 nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                                 pageID: pageID,
                                 titlechk: check_title,
                                 deschk: check_des,
                             };

                             promises.push(() => makeAjaxRequest(requestData));
                         });
                     }

                     if (check_des == 'yes' && check_title == 'no') {
                         descr_selctbox.forEach(function(title) {
                             var pdisarr = title.split('_');
                             var pageID = pdisarr[3];
                             var requestData = {
                                 action: 'fetchmeta_rec',
                                 nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                                 pageID: pageID,
                                 titlechk: check_title,
                                 deschk: check_des,
                             };

                             promises.push(() => makeAjaxRequest(requestData));
                         });
                     }

                     if (check_title == 'yes' && check_des == 'yes') {
                         title_selctbox.forEach(function(title) {
                             var pdisarr = title.split('_');
                             var pageID = pdisarr[3];
                             var requestData = {
                                 action: 'fetchmeta_rec',
                                 nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                                 pageID: pageID,
                                 titlechk: check_title,
                                 deschk: check_des,
                             };

                             promises.push(() => makeAjaxRequest(requestData));
                         });
                     }

                     var delayBetweenRequests = 50;

                     executePromisesSequentiallyWithDelay(promises, delayBetweenRequests)
                         .then(responses => {
                             jQuery('#custom-loader').removeClass('show');
                             get_request_limit();
                             console.log('All requests completed.');
                         })
                         .catch(error => {
                             jQuery('#custom-loader').removeClass('show');
                             console.error(error);
                         });
                 });*/




                $('.bulk_gen').click(function() {

                    var check_title = "no";
                    var check_des = "no";
                    if ($(".meta_titl_desc").prop("checked")) {
                        check_title = "yes";
                    }

                    if ($(".meta_desc").prop("checked")) {
                        check_des = "yes";
                    }

                    var title_selctbox = [];
                    var descr_selctbox = [];

                    // Iterate over each checkbox with class "title_checkbox"
                    $('.title_checkbox').each(function() {
                        // Check if the checkbox is checked
                        if ($(this).prop('checked')) {
                            // If checked, push its name to the selectedCheckboxes array
                            title_selctbox.push($(this).attr('name'));
                        }
                    });

                    // if (check_des == "yes") {
                    $('.meta_des_box').each(function() {
                        // Check if the checkbox is checked
                        if ($(this).prop('checked')) {
                            // If checked, push its name to the selectedCheckboxes array
                            descr_selctbox.push($(this).attr('name'));
                        }
                    });
                    // }
                    var titelnt = title_selctbox.length;
                    var desclen = descr_selctbox.length;
                    var sumtoken = titelnt + desclen;
                    alert('You are consuming ' + sumtoken + ' tokens');
                    jQuery('#custom-loader_cust').addClass('show');
                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: {
                            action: 'bulk_meta_genrate',
                            nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                            p_meta_t: title_selctbox,
                            p_meta_d: descr_selctbox,
                            gettype_title: check_title,
                            gettype_desc: check_des
                            //post_des: pagdescrition,
                        },
                        success: function(response) {
                            jQuery('#custom-loader_cust').removeClass('show');
                            var resdata = JSON.parse(response);

                            if (resdata.msg == "disconnect") {
                                showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                            } else if (resdata.msg == "request_limit") {
                                showSuccessPopup('Request limit reached');
                            } else if (resdata.msg == "insuffconnect") {
                                showSuccessPopup('You have insufficient connect for request');
                            } else {
                                if (check_title == 'yes' && check_des == 'no') {
                                    for (var key_title in resdata) {
                                        var pstid = key_title;
                                        var title_text = resdata[key_title].gen_ai;
                                        var getval = document.querySelector('textarea[name="meta_title_2_' + pstid + '"]');
                                        getval.value = title_text;

                                    }

                                } else if (check_des == 'yes' && check_title == 'no') {
                                    for (var key_des in resdata) {
                                        var pstid = key_des;
                                        var dwesxtext = resdata[key_des].gen_ai;
                                        console.log(pstid);
                                        var getvaldes = document.querySelector('textarea[name="meta_description_2_' + pstid + '"]');
                                        if (getvaldes) {
                                            getvaldes.value = dwesxtext || "";
                                        }

                                    }

                                } else if (check_des == 'yes' && check_title == 'yes') {
                                    for (const key in resdata) {
                                        const pstid = key;
                                        const pos_titl = resdata[key].gen_ai_title;
                                        const pos_titdesc = resdata[key].gen_ai_description;
                                        var getval_title = document.querySelector('textarea[name="meta_title_2_' + pstid + '"]');
                                        var getval_desc = document.querySelector('textarea[name="meta_description_2_' + pstid + '"]');
                                        getval_title.value = pos_titl;
                                        if (getval_desc) {
                                            getval_desc.value = pos_titdesc || "";
                                        }

                                    }

                                }
                                get_request_limit();
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });

                });

                $('.bulk_update').click(function() {

                    var check_title = "no";
                    var check_des = "no";
                    if ($(".meta_titl_desc").prop("checked")) {
                        check_title = "yes";
                    }

                    if ($(".meta_desc").prop("checked")) {
                        check_des = "yes";
                    }

                    var title_selctbox = [];
                    var descr_selctbox = [];

                    // Iterate over each checkbox with class "title_checkbox"
                    $('.postp_title').each(function() {
                        var tlname = $(this).attr('name');
                        var prtids = tlname.split('_');
                        var pstids = prtids[3];
                        //title_selctbox[pstids] = $(this).val();
                        // var obj = {}; // Create an object
                        // obj[pstids] = $(this).val(); // Set the ID as index and value
                        // title_selctbox.push(obj); // Push the object into the array
                        title_selctbox.push({
                            [pstids]: $(this).val()
                        });


                    });


                    $('.postp_des').each(function() {
                        // Check if the checkbox is checked
                        // If checked, push its name to the selectedCheckboxes array
                        var desname = $(this).attr('name');
                        var desprtids = desname.split('_');
                        var dspstids = desprtids[3];

                        descr_selctbox.push({
                            [dspstids]: $(this).val()
                        });

                    });


                    jQuery('#custom-loader_cust').addClass('show');
                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: {
                            action: 'bulk_update_meta',
                            nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                            p_meta_t: title_selctbox,
                            p_meta_d: descr_selctbox,
                            gettype_title: check_title,
                            gettype_desc: check_des
                            //post_des: pagdescrition,
                        },
                        success: function(response) {
                            jQuery('#custom-loader_cust').removeClass('show');
                            if (check_title == 'yes') {
                                $('.postp_title').each(function() {
                                    var tlname = $(this).attr('name');
                                    var prtids = tlname.split('_');
                                    var pstids = prtids[3];

                                    var getval = document.querySelector('textarea[name="meta_title_1_' + pstids + '"]');
                                    getval.value = $(this).val();

                                });
                            }
                            if (check_des == 'yes') {
                                $('.postp_des').each(function() {
                                    var tlname = $(this).attr('name');
                                    var prtids = tlname.split('_');
                                    var pstids = prtids[3];
                                    var getval = document.querySelector('textarea[name="meta_des_1_' + pstids + '"]');
                                    getval.value = $(this).val();

                                });
                            }
                            // var resdata = JSON.parse(response);
                            // console.log(resdata);

                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                        }
                    });

                });

            });

            function call_filter() {
                var selectElement = document.getElementById("page_filter");
                var selectedValue = selectElement.value;
                //console.log(selectedValue); // This will log the selected value to the console
                if (selectedValue != "") {
                    // Adding parameter to the URL
                    var paramName = "aifilterpage";
                    var paramValue = selectedValue;
                    addParameterToURL(paramName, paramValue);
                }
            }

            // Function to add a parameter to the URL
            function addParameterToURL(paramName, paramValue) {
                var url = window.location.href;

                // Check if the URL already contains parameters
                if (url.indexOf('?') !== -1) {
                    // URL already contains parameters
                    url += '&' + paramName + '=' + paramValue;
                } else {
                    // URL does not contain parameters
                    url += '?' + paramName + '=' + paramValue;
                }

                // Redirect to the updated URL
                window.location.href = url;
            }

            function get_request_limit() {

                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'fetch_req_limit',
                        nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    },
                    success: function(response) {
                        var resdata = JSON.parse(response);
                        if (resdata.msg == "disconnect") {
                            jQuery(".fetch_data").remove();
                            jQuery(".bulk_gen").remove();
                            //alert('Disconnect License Key');
                        } else {
                            jQuery("#token_usgae").html("Token Usage: <strong>" + resdata.request_limit + "/" + resdata.total_limit + "</strong");
                        }

                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });

            }
            get_request_limit();
        </script>