</div>
 
</div>






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
$(".activeExCgtable").slideUp();
  $(".clickToExpand").click(function(){
   $(this).addClass("activeExpand");
    $(".activeExCgtable").slideToggle();
  });
});
</script>

</div>
</body>
</html>