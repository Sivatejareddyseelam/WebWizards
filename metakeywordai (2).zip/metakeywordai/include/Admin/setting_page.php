<div class="flexLogin">
    <div class="flexLoginChild flexLoginChild70">
        <div class="welcomeLogin welcomeProfile">
            <h5>Manage SEO Plugin</h5>
            <div class="maxwd415">
                <p>Please select which plugin you are using.</p>
            </div>

            <div class="loginFormTop profileForm">
                <form method="post">
                    <div class="flexF">
                        <select name="using_plugin">
                            <option value="">Select Plugin</option>
                            <option <?php if ($seo_activae_plugin == 'cg_aioseo') { ?> selected <?php } ?> value="cg_aioseo">AIOSEO</option>
                            <option <?php if ($seo_activae_plugin == 'cg_yoast') { ?> selected <?php } ?> value="cg_yoast">Yoast</option>
                            <option <?php if ($seo_activae_plugin == 'cg_rank_math') { ?> selected <?php } ?> value="cg_rank_math">Rank Match</option>
                        </select>
                    </div>

                    <input type="submit" value="Submit" class="btn btn-block btn-primary track_user_plugin">
                    <span id="user_infodata"></span>

                </form>

            </div>


        </div>

    </div>
    <div class="flexLoginChild">

        <div class="imageLogoMeta imageLogoMetaCenter"><img src="images/logV2.png" /></div>
        <div class="infoCG67New">
            <h5>Quis autem vel eum iure reprehenderit</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
        </div>

    </div>

</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
    $(document).on('click', '.track_user_plugin', function(e) {
        e.preventDefault(); // Prevent default form submission
        // Validate form fields      


        var form = $(this).closest('form');
        jQuery('#custom-loader_cust').addClass('show');
        // Serialize the form data
        var formData = form.serialize();

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'track_plugin_data',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                fromdata: formData,
            }, // Form data
            success: function(response) {
                jQuery('#custom-loader_cust').removeClass('show');
                jQuery('#user_infodata').html('Data updated successfully');
                jQuery('#user_infodata').css('color', 'green');

            },
            error: function(xhr, status, error) {
                alert('Error occurred while updating alt tags.');
                // Optionally, you can handle error response
            }
        });
    });

    // Function to validate email format
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
</script>