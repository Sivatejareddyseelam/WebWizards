<div class="overlay" id="overlay"></div>

<div class="popup" id="popup"><div class="cRosspopup">
<a onclick="closePopup()" herf="javascript:void(0);" class="crossIconMeta">x</a>
    <h2>sign <span>up</span></h2>
    <input type="email" id="email" placeholder="Your Email">
    <button onclick="submitEmail()">Submit</button>
    <span style="display:none;" id="message_show"></span>
</div></div>

<div class="infoCG67New">
    <h5>Quis autem vel eum iure reprehenderit</h5>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
</div>

<div class="flexVideo">
    <div class="bg0265f6 wdequal6">
        <iframe src="https://player.vimeo.com/video/347119375?h=1699409fe2&color=ef2200&byline=0&portrait=0" width="100%" height="257" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="infoVideo4Cg wdequal6">
        <h4>How this plugin works?</h4>
        <ul>
            <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque.</li>
            <li>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni.</li>
            <li>Ut enim ad minima veniam, quis nostrum exercitationem.</li>
        </ul>
    </div>
</div>


<div class="pricingYearly">
    <div id="tabs">
        <div class="pricingYearlyWd">
            <div class="headingP">
                <h3>Simple, transparent pricing</h3>
                <p>No contracts. No surprise fees.</p>
            </div>
            <div class="tabs2">
                <ul>
                    <li><a href="#tabs-1">Monthly</a></li>
                    <li><a href="#tabs-2">Yearly</a></li>
                </ul>
            </div>
        </div>

        <div id="tabs-1">
            <div class="tabsFlexmain">
                <div class="tabsFlexmainINnner">
                    <div class="introP">Intro</div>
                    <div class="dollerM">Free</div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="javascript:void(0);" onclick="openPopup()" class="choosePlan">Chosse Plan</a>
                </div>

                <div class="tabsFlexmainINnner">
                    <div class="introP">Base</div>
                    <div class="dollerM">$33 <span>/Month</span></div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="#" class="choosePlan">Chosse Plan</a>
                </div>

                <div class="tabsFlexmainINnner activated">
                    <div class="introP">Popular</div>
                    <div class="dollerM">$99 <span>/Month</span></div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="#" class="choosePlan">Chosse Plan</a>
                </div>

                <div class="tabsFlexmainINnner">
                    <div class="introP">Enterprise</div>
                    <div class="dollerM">$199 <span>/Month</span></div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="#" class="choosePlan">Chosse Plan</a>
                </div>

            </div>
        </div>
        <div id="tabs-2">
            <div class="tabsFlexmain">
                <div class="tabsFlexmainINnner">
                    <div class="introP">Intro</div>
                    <div class="dollerM">$19 <span>/Year</span></div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="#" class="choosePlan">Chosse Plan</a>
                </div>

                <div class="tabsFlexmainINnner">
                    <div class="introP">Base</div>
                    <div class="dollerM">$33 <span>/Year</span></div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="#" class="choosePlan">Chosse Plan</a>
                </div>

                <div class="tabsFlexmainINnner activated">
                    <div class="introP">Popular</div>
                    <div class="dollerM">$99 <span>/Year</span></div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="#" class="choosePlan">Chosse Plan</a>
                </div>

                <div class="tabsFlexmainINnner">
                    <div class="introP">Enterprise</div>
                    <div class="dollerM">$199 <span>/Year</span></div>
                    <div class="topP">For most businesses that want to optimize web queries</div>
                    <ul>
                        <li>All limited links</li>
                        <li>Own analytics platform</li>
                        <li>Chat support</li>
                        <li>Optimize hashtags</li>
                        <li>Unlimited users</li>
                    </ul>
                    <a href="#" class="choosePlan">Chosse Plan</a>
                </div>

            </div>
        </div>

    </div>
    <!-- <button onclick="openPopup()">Enter Email</button> -->


</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script>
    $(function() {
        $("#tabs").tabs();
    });
</script>
<script>
    // Function to display the popup
    function openPopup() {
        document.getElementById('popup').style.display = 'block';
        document.getElementById('overlay').style.display = 'block';
    }

    // Function to close the popups
    function closePopup() {
        document.getElementById('popup').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
    }
 
    // Function to submit the email
    function submitEmail() {
        var email = document.getElementById('email').value;
        jQuery('#custom-loader').addClass('show');
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',   
            data: {
                action: 'plug_reg_portal',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                email: email,
            }, // Form data
            success: function(response) {
                jQuery('#custom-loader').removeClass('show');
                var get_res = JSON.parse(response);
                if (get_res.msg == "reg") {
                    jQuery('#message_show').css('display', 'block');
                    jQuery('#message_show').html('Licence Key and password sent to your email address');
                } else {
                    jQuery('#message_show').css('display', 'block');
                    jQuery('#message_show').html('Your email is already registered');
                }
            },
            error: function(xhr, status, error) {
                alert('Error occurred while updating alt tags.');
                // Optionally, you can handle error response
            }
        });
        // Close the popup after submission
        //closePopup();
    }
</script>