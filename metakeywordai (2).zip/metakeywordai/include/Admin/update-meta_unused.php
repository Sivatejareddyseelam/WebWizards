<?php
// Load WordPress
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');

// Check if it's a POST request and if the user is logged in
if ($_SERVER['REQUEST_METHOD'] === 'POST' && is_user_logged_in()) {
    // Verify nonce
    $nonce = $_POST['nonce'];
    if (!wp_verify_nonce($nonce, 'update_meta_nonce')) {
        wp_send_json_error('Invalid nonce.');
        exit;
    }

    // Sanitize and validate inputs
    $pageID = isset($_POST['pageID']) ? intval($_POST['pageID']) : 0;
    $metaTitle = isset($_POST['metaTitle']) ? sanitize_text_field($_POST['metaTitle']) : '';
    $metaDescription = isset($_POST['metaDescription']) ? sanitize_text_field($_POST['metaDescription']) : '';

    // Check if the page ID is valid
    if (!$pageID || !get_post($pageID)) {
        wp_send_json_error('Invalid page ID.');
        exit;
    }
     print_r($_POST);
    // Update meta titles and descriptions using update_post_meta function
    update_post_meta($pageID, '_aioseo_title', $metaTitle);
    update_post_meta($pageID, '_aioseo_description', $metaDescription);

    // Return success message
    wp_send_json_success('sssMeta information updated successfully.');
} else {
    // Return error message if it's not a POST request or user is not logged in
    wp_send_json_error('Unauthorized access.');
}
