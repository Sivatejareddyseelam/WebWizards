<div id="custom-loader" class="loader">
    <div class="progress-container">
        <div class="progress-bar"></div>
        <div class="percentage-text">0%</div>
    </div>
</div>

<style>
    .loader {
        display: none;
        /* Initially hidden */
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80%;
        background-color: #f3f3f3;
        border: 1px solid #ccc;
        border-radius: 5px;
        text-align: center;
        padding: 10px;
        z-index: 9999;
    }

    .progress-container {
        position: relative;
        width: 100%;
        height: 30px;
        background-color: #ddd;
        border-radius: 5px;
        overflow: hidden;
    }

    .progress-bar {
        height: 100%;
        background-color: #4caf50;
        width: 0;
        transition: width 0.5s;
    }

    .percentage-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        margin: 0;
        font-size: 16px;
        color: #fff;
    }
</style>
<?php

function get_post_description($post_id)
{
    $post = get_post($post_id);
    if ($post) {
        // Get the post content and strip HTML tags
        $description = wp_strip_all_tags($post->post_content);
        return $description;
    }
    return false;
}
$aifilterpage = isset($_GET['aifilterpage']) ? $_GET['aifilterpage'] : 10; // Current page number

?>




<div class="flexButtonsCg">
    <div class="gridFlexCg">
        <ul class="buttonsCg">
            <li><a id="pages-tab" href="admin.php?page=cg_meta_al_list" class="normalBtnCG normalBtnCGV2">Pages</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_product" class="normalBtnCG normalBtnCGV2">Products</a></li>
            <li><a id="posts-tab" href="admin.php?page=cg_meta_al_altag" class="normalBtnCG ">Alt Tags</a></li>

        </ul>
    </div>

    <!-- <div class="gridFlexCg justifyRight">
        <ul class="buttonsCg">
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_gen">Generate Bulk Information</a></li>
            <li><a style="cursor:pointer;" class="normalBtnCG normalBtnCGV3 bulk_update">Update Bulk Information</a></li>
        </ul>
    </div> -->
</div>

<div class="flexButtonsCg" style="margin-top:5px;">
    <div class="gridFlexCg">
        <select id="page_filter" onchange="call_filter();">
            <option value="">select filter</option>
            <option <?php if ($aifilterpage == 5) { ?> selected <?php } ?> value="5">5</option>
            <option <?php if ($aifilterpage == 10) { ?> selected <?php } ?> value="10">10</option>
            <option <?php if ($aifilterpage == 30) { ?> selected <?php } ?> value="30">30</option>
            <option <?php if ($aifilterpage == 50) { ?> selected <?php } ?> value="50">50</option>
        </select>
    </div>
    <div class="gridFlexCg justifyRight">
        <span id="token_usgae"></span>
    </div>
</div>

<div class="tableStCg" class="tab-pane fade show active" id="pages" role="tabpanel" aria-labelledby="pages-tab">
    <div class="scrollTable">
        <table cellpadding="0" cellspacing="0">
            <thead>
                <tr>
                    <th width="25%">Image</th>
                    <th width="25%">URLs</th>
                    <th width="25%"><label class="containerCheckmark">Alt Tag<!--<input type="checkbox" class="alt_tag" name="alt_tag"><span class="checkmark"></span>--></label></th>
                    <th width="25%" style="text-align:center;">Action</th>
                </tr>
            </thead>
        </table>
        <div class="borderSeparate">
            <?php

            //foreach ($pages as $page) :

            $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number

            $args = array(
                'post_type' => 'attachment', // Include both posts and pages
                'post_status' => 'inherit', // Only published posts/pages
                'posts_per_page' => $aifilterpage, // Limiting to 10 posts/pages per page
                'offset' => ($paged - 1) * $aifilterpage, // Offset calculation
            );
            $query = new WP_Query($args);
            while ($query->have_posts()) : $query->the_post();



                $post_id = get_the_ID();
            ?>

                <table cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td width="25%">
                                <div class="titLeLink titLeLinkWeight500">
                                    <div class="bgMainGrid" style="background:url('<?php echo wp_get_attachment_url(); ?>') no-repeat"></div>
                            </td>
                            <td width="25%">
                                <div class="titLeLink"><a href="<?php echo wp_get_attachment_url(); ?>"><?php echo wp_get_attachment_url(); ?></a></div>
                            </td>

                            <td width="25%">
                                <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                    <div class="flexCheckCgChild flexCheckCgChildReadOnly PDleft22">
                                        <div class="textareaType">
                                            <textarea id="meta_des_1_<?php echo $post_id; ?>" readonly><?php echo get_post_meta($post_id, '_wp_attachment_image_alt', true); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                    <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="alt_checkbox pre_des_chk" desreqatt="0" name="meta_d_2_chkd_<?php echo $post_id; ?>" value="2" name="meta_d_radio_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                    <div class="flexCheckCgChild PDleft22"><textarea class="altg_aig" name="meta_des_2_<?php echo $post_id; ?>" placeholder="Alt tag"></textarea></div>
                                </div>
                                <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                    <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="alt_checkbox pre_des_chk" desreqatt="1" name="meta_d_3_chkd_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                    <div class="flexCheckCgChild PDleft22"><textarea class="altg_aig" name="meta_des_3_<?php echo $post_id; ?>" placeholder="Alt tag"></textarea></div>
                                </div>
                                <div class="flexCheckCg flexCheckCgNoFlex extraHeight">
                                    <div class="flexCheckCgChild flexCheckCgChildV2"><label class="containerCheckmark"><input type="checkbox" class="alt_checkbox pre_des_chk" desreqatt="2" name="meta_d_4_chkd_<?php echo $post_id; ?>" value="2"><span class="checkmark"></span></label></div>
                                    <div class="flexCheckCgChild PDleft22"><textarea class="altg_aig" name="meta_des_4_<?php echo $post_id; ?>" placeholder="Alt tag"></textarea></div>
                                </div>
                            </td>
                            <input type="hidden" id="regen_<?php echo $post_id; ?>" value="">
                            <td width="25%" style="text-align:center;">
                                <div class="generatePlain heightBtnCenter2"><button class="btnWdH clickToExpand fetch_data" data-id="<?php echo $post_id; ?>">Fetch</button></div>
                                <div class="generatePlain heightBtnCenter2"><button class="btnWdH blueBtncg update-btn" data-page-id="<?php echo $post_id; ?>">Update</button></div>
                            </td>
                        </tr>
                    </tbody>
                </table>


                <div class="activeExCgtable paddingAreaCg" id="main_imgid_<?php echo $post_id; ?>" style="display: none;">
                    <div class="activeExCgtableH6">
                        <h6>Alt Tags Generation</h6>
                        <div class="gridFlexCG" id="imgid_<?php echo $post_id; ?>">



                        </div>
                    </div>
                </div>

            <?php //endforeach;

            endwhile;
            ?>
        </div>
        <?php

        $total_pages = $query->max_num_pages;

        // Get the current page number
        // $paged = max(1, get_query_var('paged', 1));
        $paged = isset($_GET['paged']) ? $_GET['paged'] : 1; // Current page number

        // Check if there's more than one page
        if ($total_pages > 1) {
            echo '<div class="flexDirectionCg">'; // Opening div tag

            // Generate pagination links
            echo paginate_links(array(
                'base'      => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                'format'    => '?paged=%#%',
                'current'   => $paged,
                'total'     => $total_pages,
                'mid_size'  => 2,
                'prev_text' => __('« Previous'),
                'next_text' => __('Next »'),
            ));

            echo '</div>'; // Closing div tag
        }


        wp_reset_postdata(); // Reset Post Data

        ?>
    </div>
</div>


<!-- JavaScript to handle click event of view links -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
    function showSuccessPopup(message) {
        // Create a new element for the popup message
        var popup = document.createElement('div');
        popup.innerHTML = '<div class="overlay" id="overlay"></div> <div class="updatedDataNow">' +
            '<p>' + message + '</p>' +
            '<button id="closeButton">Close</button>' +
            '</div>';

        // Style the popup element
        popup.style.position = 'fixed';
        popup.style.top = '50%';
        popup.style.left = '50%';
        popup.style.transform = 'translate(-50%, -50%)';
        popup.style.backgroundColor = 'rgb(0 0 0 / 27%)';
        popup.style.border = '1px solid #cccccc';
        popup.style.padding = '20px';
        popup.style.zIndex = '10000';
        popup.style.width = '100%';
        popup.style.height = '100%';

        // Append the popup to the body
        document.body.appendChild(popup);

        // Close the popup when the close button is clicked
        var closeButton = document.getElementById('closeButton');
        closeButton.addEventListener('click', function() {
            document.body.removeChild(popup);
        });
    }
    jQuery(document).ready(function($) {
        // Handle click event of view links
        $('.view-link').click(function(e) {
            e.preventDefault();
            // Hide all previously expanded meta info
            $('.meta-info').hide();
            // Fetch the ID and type of the clicked item
            var id = $(this).data('id');
            // Show the meta info corresponding to the clicked item
            $('#mpg_' + id).toggle();
        });


    });

    jQuery(document).ready(function($) {
        $('.fetch_data').click(function() {

            var pageID = $(this).attr('data-id');

            var pagdescrition = $("#psdes_" + pageID).val();


            var titlechk = "no";
            var deschk = "no";


            var metaTitleRadioButton = $('input[name="meta_t_radio_' + pageID + '"]:checked');

            if (metaTitleRadioButton.length > 0) {
                titlechk = "yes";
            }

            var metaDescriptionRadioButton = $('input[name="meta_d_radio_' + pageID + '"]:checked');
            if (metaDescriptionRadioButton.length > 0) {
                deschk = "yes";
            }


            var chkregen = $("#regen_" + pageID).val();
            jQuery('#custom-loader_cust').addClass('show');

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'fetchalt_rec',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    titlechk: titlechk,
                    deschk: deschk,

                },
                success: function(response) {

                    jQuery('#custom-loader_cust').removeClass('show');
                    var resdata = JSON.parse(response);
                    if (resdata.msg == "disconnect") {
                        showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                    } else if (resdata.msg == "request_limit") {
                        alert('Request limit reached');
                    } else if (resdata.msg == "invalid") {
                        alert('Invalid user');
                    } else {
                        if (titlechk == 'yes') {
                            var getval = document.querySelector('textarea[name="meta_title_2_' + pageID + '"]');
                            getval.value = resdata.data.text.meta_title;
                        }

                        if (chkregen != "") {

                            $('.pre_des_chk:checked').each(function() {

                                var getvalue = $(this).attr('desreqatt');

                                var mettlename = $(this).attr('name');
                                var splitcrtd = mettlename.split("_");
                                console.log(splitcrtd);
                                if (resdata.data == "not_found") {
                                    $('textarea[name="meta_des_' + splitcrtd[2] + '_' + pageID + '"]').val('not_found');
                                } else {
                                    $('textarea[name="meta_des_' + splitcrtd[2] + '_' + pageID + '"]').val(resdata.data.text.images[pageID][getvalue]);
                                }

                            });

                        } else {

                            if (resdata.data == "not_found") {
                                var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                metdesval1.value = "not_found";

                                var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                metdesval2.value = "not_found";

                                var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                metdesval3.value = "not_found";

                            } else {
                                var metdesval1 = document.querySelector('textarea[name="meta_des_2_' + pageID + '"]');
                                metdesval1.value = resdata.data.text.images[pageID][0];

                                var metdesval2 = document.querySelector('textarea[name="meta_des_3_' + pageID + '"]');
                                metdesval2.value = resdata.data.text.images[pageID][1];

                                var metdesval3 = document.querySelector('textarea[name="meta_des_4_' + pageID + '"]');
                                metdesval3.value = resdata.data.text.images[pageID][2];
                            }
                        }

                    }

                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });

        });


        $('.get_alt_tag').click(function() {
            var pageID = $(this).attr('data-id');
            // Show WordPress admin default spinner
            jQuery('#custom-loader').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'getalt_img',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                },
                success: function(response) {
                    jQuery('#custom-loader').removeClass('show');
                    var imgtagdta = JSON.parse(response);
                    $("#main_imgid_" + pageID).css('display', 'inline-block');
                    $("#imgid_" + pageID).html(imgtagdta.data);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                },
                complete: function() {
                    // Hide WordPress admin default spinner
                    jQuery('#custom-loader').removeClass('show');
                }
            });
        });


        $('.update-btn').click(function() {
            var pageID = $(this).data('page-id');


            var titlechk = "no";
            var deschk = "no";

            var getdesc = $('.pre_des_chk:checked');
            if (getdesc.length > 1) {
                alert('Please select single meta title and description to update on your web page');
                return false;
            }

            if (getdesc.length == 1) {
                deschk = "yes";
            }
            var metaDescriptiontxt = "";
            if (deschk == "yes") {
                var metades = getdesc.attr('name');
                var splitcrtd2 = metades.split("_");
                console.log(splitcrtd2)
                metaDescriptiontxt = $('textarea[name="meta_des_' + splitcrtd2[2] + '_' + pageID + '"]').val();
            }



            jQuery('#custom-loader_cust').addClass('show');
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'update_meta_action',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    pageID: pageID,
                    alt_tag: metaDescriptiontxt
                },
                success: function(response) {
                    jQuery('#custom-loader_cust').removeClass('show');
                    // Update meta info display
                    showSuccessPopup('Updated Successfully');

                    if (titlechk == 'yes') {
                        document.getElementById('meta_des_1_' + pageID).value = metaDescriptiontxt

                    }

                    // Update meta info display

                    $('#mpg_' + pageID + ' .meta-description').text(metaDescriptiontxt);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        // Add a click event handler for the submit button of each form
        $(document).on('click', '.alt_sub', function(e) {
            e.preventDefault(); // Prevent default form submission

            var form = $(this).closest('form');
            jQuery('#custom-loader').addClass('show');
            // Serialize the form data
            var formData = form.serialize();

            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'update_image_alt_text',
                    nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                    fromdata: formData,
                }, // Form data
                success: function(response) {
                    jQuery('#custom-loader').removeClass('show');
                    showSuccessPopup('Updated Successfully');
                    // Optionally, you can handle success response
                },
                error: function(xhr, status, error) {
                    alert('Error occurred while updating alt tags.');
                    // Optionally, you can handle error response
                }
            });
        });

    });

    $("body").on("click", ".alt_tag", function() {
        if ($(this).prop("checked")) {
            $(".alt_checkbox").prop("checked", true);
        } else {
            $(".alt_checkbox").prop("checked", false);
        }

    });


    $('.bulk_gen').click(function() {

        var check_title = "no";
        var check_des = "no";
        if ($(".alt_checkbox").prop("checked")) {
            check_title = "yes";
        }



        var title_selctbox = [];

        // Iterate over each checkbox with class "title_checkbox"
        $('.alt_checkbox').each(function() {
            // Check if the checkbox is checked
            if ($(this).prop('checked')) {
                // If checked, push its name to the selectedCheckboxes array
                title_selctbox.push($(this).attr('name'));
            }
        });


        var titelnt = title_selctbox.length;

        alert('You are consuming ' + titelnt + ' tokens');
        jQuery('#custom-loader_cust').addClass('show');
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'bulk_meta_alt_genrate',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                p_meta_t: title_selctbox,
                gettype_title: check_title,
            },
            success: function(response) {
                jQuery('#custom-loader_cust').removeClass('show');
                var resdata = JSON.parse(response);

                if (resdata.msg == "disconnect") {
                    showSuccessPopup('Your site is not connected with license key, please connect it from dashboard');
                } else if (resdata.msg == "request_limit") {
                    showSuccessPopup('Request limit reached');
                } else if (resdata.msg == "insuffconnect") {
                    showSuccessPopup('You have insufficient connect for request');
                } else if (resdata.msg == "not_found") {
                    showSuccessPopup('no ai data found');
                } else {

                    resdata.forEach(image => {
                        console.log(image.image_id);
                        console.log(image.alt_tag);
                        var getval = document.querySelector('textarea[name="meta_description_2_' + image.image_id + '"]');
                        getval.value = image.alt_tag;
                    });
                }

            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    });

    $('.bulk_update').click(function() {

        var check_title = "no";
        var check_des = "no";
        if ($(".meta_titl_desc").prop("checked")) {
            check_title = "yes";
        }

        if ($(".meta_desc").prop("checked")) {
            check_des = "yes";
        }

        var title_selctbox = [];
        var descr_selctbox = [];

        // Iterate over each checkbox with class "title_checkbox"
        $('.altg_aig').each(function() {
            var tlname = $(this).attr('name');
            var prtids = tlname.split('_');
            var pstids = prtids[3];
            title_selctbox.push({
                [pstids]: $(this).val()
            });


        });



       
        jQuery('#custom-loader_cust').addClass('show');
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'bulk_alt_update_meta',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                p_meta_alt: title_selctbox,
                //post_des: pagdescrition,
            },
            success: function(response) {
                jQuery('#custom-loader_cust').removeClass('show');
                showSuccessPopup('Updated Successfully');
                $('.altg_aig').each(function() {
                    var tlname = $(this).attr('name');
                    var prtids = tlname.split('_');
                    var pstids = prtids[3];
                    document.getElementById('meta_des_1_' + pstids + '').value = $(this).val();
                });


            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });

    });



    function call_filter() {
        var selectElement = document.getElementById("page_filter");
        var selectedValue = selectElement.value;
        //console.log(selectedValue); // This will log the selected value to the console
        if (selectedValue != "") {
            // Adding parameter to the URL
            var paramName = "aifilterpage";
            var paramValue = selectedValue;
            addParameterToURL(paramName, paramValue);
        }
    }

    // Function to add a parameter to the URL
    function addParameterToURL(paramName, paramValue) {
        var url = window.location.href;
        var urlParts = url.split('?');

        // Check if parameters exist in the URL
        if (urlParts.length > 1) {
            var params = urlParts[1].split('&');
            var paramExists = false;

            // Loop through existing parameters
            for (var i = 0; i < params.length; i++) {
                var param = params[i].split('=');

                // If parameter already exists, update its value
                if (param[0] === paramName) {
                    param[1] = paramValue;
                    params[i] = param.join('=');
                    paramExists = true;
                    break;
                }
            }

            // If parameter doesn't exist, add it
            if (!paramExists) {
                params.push(paramName + '=' + paramValue);
            }

            // Reconstruct the URL with updated parameters
            url = urlParts[0] + '?' + params.join('&');
        } else {
            // If no parameters exist, simply add the new parameter
            url += '?' + paramName + '=' + paramValue;
        }

        // Redirect to the updated URL
        window.location.href = url;
    }

    function get_request_limit() {

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'fetch_req_limit',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
            },
            success: function(response) {
                var resdata = JSON.parse(response);
                if (resdata.msg == "disconnect") {
                    jQuery(".fetch_data").remove();
                    jQuery(".bulk_gen").remove();
                    //alert('Disconnect License Key');
                } else {
                    jQuery("#token_usgae").html("Token Usage: <strong>" + resdata.request_limit + "/" + resdata.total_limit + "</strong");
                }

            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });

    }
    get_request_limit();
</script>