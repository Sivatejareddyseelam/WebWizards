<div class="flexLogin">
    <div class="flexLoginChild flexLoginChild70">
        <div class="welcomeLogin welcomeProfile">
            <h5>Manage Profile</h5>
            <div class="maxwd415">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
            </div>

            <div class="loginFormTop profileForm">
                <form method="post">
                    <div class="flexF">
                        <input type="text" placeholder="First Name" name="f_name" value="<?php echo isset($alldata[0]->first_name) ? $alldata[0]->first_name : ''; ?>" />
                        <input type="text" placeholder="Last Name" name="l_name" value="<?php echo isset($alldata[0]->last_name) ? $alldata[0]->last_name : ''; ?>" />
                        <input type="email" placeholder="Email" name="email" value="<?php echo isset($alldata[0]->email) ? $alldata[0]->email : ''; ?>" />
                        <input type="text" placeholder="Phone" name="phone" value="<?php echo isset($alldata[0]->phone) ? $alldata[0]->phone : ''; ?>" />
                    </div>

                    <?php
                    if ($alldata == "disconnect") {
                        echo "Disbaled License Key";
                    } else if ($alldata == "invalid") {
                        echo "Invalid License Key";
                    } else { ?>
                        <input type="submit" value="Submit" class="btn btn-block btn-primary track_user_data">
                    <?php } ?>
                    <span id="user_infodata"></span>
                </form>

            </div>


        </div>

    </div>
    <div class="flexLoginChild">

        <div class="imageLogoMeta imageLogoMetaCenter"><img src="images/logV2.png" /></div>
        <div class="infoCG67New">
            <h5>Quis autem vel eum iure reprehenderit</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
        </div>

    </div>

</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
    $(document).on('click', '.track_user_data', function(e) {
        e.preventDefault(); // Prevent default form submission
        // Validate form fields
        var errors = [];

        // Validate first name
        var firstName = $('input[name="f_name"]').val().trim();
        if (firstName === '') {
            errors.push('First name is required.');
        }

        // Validate last name
        var lastName = $('input[name="l_name"]').val().trim();
        if (lastName === '') {
            errors.push('Last name is required.');
        }

        // Validate email
        var email = $('input[name="email"]').val().trim();
        if (email === '') {
            errors.push('Email is required.');
        } else if (!isValidEmail(email)) {
            errors.push('Invalid email format.');
        }

        // Validate phone
        var phone = $('input[name="phone"]').val().trim();
        if (phone === '') {
            errors.push('Phone is required.');
        }

        // Display validation errors if any
        // if (errors.length > 0) {
        //     var errorMessage = '<ul style="color:red;">';
        //     $.each(errors, function(index, error) {
        //         errorMessage += '<li>' + error + '</li>';
        //     });
        //     errorMessage += '</ul>';
        //     $('#user_infodata').html(errorMessage);
        //     return;
        // }
        var form = $(this).closest('form');
        jQuery('#custom-loader').addClass('show');
        // Serialize the form data
        var formData = form.serialize();

        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'track_profile_data',
                nonce: '<?php echo wp_create_nonce('update_meta_nonce'); ?>',
                fromdata: formData,
            }, // Form data
            success: function(response) {
                jQuery('#custom-loader').removeClass('show');
                var resdata = JSON.parse(response);
                if (resdata.msg == "failed") {
                    var errorMessage = '<ul style="color:red;">';
                    resdata.data.forEach(function(error) {
                        errorMessage += '<li>' + error + '</li>';
                    });
                    errorMessage += '</ul>';
                    $('#user_infodata').html(errorMessage);
                } else if (resdata.msg == "success") {
                    jQuery('#user_infodata').html('user data updated successfully');
                } else if (resdata.msg == "disconnect") {
                    jQuery('#user_infodata').html('Disconnect License Key');
                } else {
                    jQuery('#user_infodata').html('Invalid details');
                }
            },
            error: function(xhr, status, error) {
                alert('Error occurred while updating alt tags.');
                // Optionally, you can handle error response
            }
        });
    });

    // Function to validate email format
    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
</script>