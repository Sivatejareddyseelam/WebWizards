<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/stylesheet-meta.css" />
<div class="setContainer">
    <div class="metaCg">
        <div class="imageLogoMeta"><img src="<?php echo plugins_url( 'images/logo.png', __FILE__ ); ?>" /></div>
        <div class="wrapCgMeta">