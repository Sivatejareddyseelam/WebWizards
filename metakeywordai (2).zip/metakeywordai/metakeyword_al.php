<?php
/*
Plugin Name: MetaKeyword AI
Description: Plugin is used for suggesting 3 versions of AI-generated meta title, meta keywords, etc.
Version: 1.0
Author: CG Colors
*/

require_once plugin_dir_path(__FILE__) . 'include/Admin/Plugin_Menu.php';
require_once plugin_dir_path(__FILE__) . 'include/Util/Helper.php';

use metakeywordai\Admin\Plugin_Menu;

// Define the activation hook callback function
function my_plugin_activation()
{
    // Check if the table exists already
    // Output the plugin page content

    // API URL
    $url = "https://phpstack-1243903-4450702.cloudwaysapps.com/metaportal/public/api/trackuser";

    // Get the admin user email
    $admin_email = get_option('admin_email');

    // Get the site URL
    $site_url = get_site_url();
    $nsite_url = str_replace("https://", " ", $site_url);
    $nsite_url = str_replace("www.", " ", $nsite_url);

    // Data to be sent in the request
    $data = array(
        'site_email' => $admin_email,
        'site_url' => trim($nsite_url)
    );

    // Initialize cURL
    $ch = curl_init();

    // Set the URL
    curl_setopt($ch, CURLOPT_URL, $url);

    // Set the request method to POST
    curl_setopt($ch, CURLOPT_POST, 1);

    // Set the POST data
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

    // Set options to return the response as a string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the request
    $response = curl_exec($ch);

    // Check for errors
    if ($response === false) {
        echo 'Curl error: ' . curl_error($ch);
    }

    // Close cURL session
    curl_close($ch);
}

// Register the activation hook
register_activation_hook(__FILE__, 'my_plugin_activation');

new Plugin_Menu();
